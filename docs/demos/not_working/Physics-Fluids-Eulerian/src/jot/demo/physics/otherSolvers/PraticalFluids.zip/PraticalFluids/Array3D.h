//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// Portions of the terrain tiling and grass code, DXUT, and basic shaders were
// adapted from the PIX Workshop GDC 2007 sample source code.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Portions of the fluid simulation are based on the original work 
// "Practical Fluid Mechanics" by Mick West used with permission.
//	http://www.gamasutra.com/view/feature/1549/practical_fluid_dynamics_part_1.php
//	http://www.gamasutra.com/view/feature/1615/practical_fluid_dynamics_part_2.php
//	http://cowboyprogramming.com/2008/04/01/practical-fluid-mechanics/
//
// Portions of the volumetric shader used with permission.
// "Real-Time Volume Graphics", Engel et. al. Ch 7, Fig. 7.1
// Copyright 2006 A K Peters Ltd.
//	http://www.real-time-volume-graphics.org/
//-------------------------------------------------------------------------------------

#pragma once

#include "BaseInclude.h"
#include <string.h>


template <typename T> 
// Creates and defines behaviors for a 1D array that is accessible as a 3D array
class Array3D
{
public:
	
	// Constructor
	Array3D(int x, int y, int z) : m_X(x), m_Y(y), m_Z(z), m_size(x*y*z)
	{
		Initialize();
	}
	
	// Constructor
	Array3D(int x, int y, int z, T initialValue) : m_X(x), m_Y(y), m_Z(z), m_size(x*y*z)
	{
		Initialize();
		Set(initialValue);
	}
	
	// Copy Constructor
	Array3D(const Array3D& arrIn) : m_X(arrIn.m_X), m_Y(arrIn.m_Y), m_Z(arrIn.m_Z), m_size(arrIn.m_X*arrIn.m_Y*arrIn.m_Z)
	{
		m_pArray = new T[arrIn.m_size];
		memcpy(m_pArray, arrIn.m_pArray, m_size*sizeof(T));
	}

	// Destructor
	virtual ~Array3D()
	{
		SAFE_DELETE_ARRAY(m_pArray);
	}

	// Returns the index in the 1D array from 3D coordinates
	inline const size_t index(int x, int y, int z) const
	{
		IASSERT(x >= 0 && x < m_X);
		IASSERT(y >= 0 && y < m_Y);
		IASSERT(z >= 0 && z < m_Z);

		return z + m_Y * (y + m_X * x);
	}
	
	// Returns the value in the array from the 3D coordinates
	inline const T& element(int x, int y, int z) const
	{
		return (m_pArray[index(x,y,z)]); 
	}

	inline T& element(int x, int y, int z)
	{
		return (m_pArray[index(x,y,z)]); 
	}

	// Returns the value in the array from the 1D coordinate
	// In a 2x2x2 array the single array will be a 0-7 index. The order will be
	// (0,0,0) (1,0,0) (0,1,0) (1,1,0)...
	inline T& element1D(unsigned int i) 
	{ 
		IASSERT(i>=0 && i<m_size);

		return (m_pArray[i]);
	}
	
	// Multiplication - Single value
	inline Array3D operator* (T value)
	{
		Array3D<T> result(*this);
		result *= value;

		return result;
	}

	// Assignment by Multiplication  - Single value
	inline void operator*= (T value)
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = m_pArray[count]*value;
		}
	}
	
	// Multiplication - arrIn values
	inline Array3D operator* (const Array3D& arrIn)
	{
		Array3D<T> result(*this);
		result *= arrIn;

		return result;
	}

	// Assignment by Multiplication
	inline void operator*= (const Array3D& arrIn)
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = m_pArray[count]*arrIn.m_pArray[count];
		}
	}

	// Division - Single value
	inline Array3D operator/ (T value)
	{
		Array3D<T> result(*this);
		result /= value;

		return result;
	}
	
	// Assignment by Division  - Single value
	inline void operator/= (T value)
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = m_pArray[count]/value;
		}
	}

	// Division - arrIn values
	inline Array3D operator/ (const Array3D& arrIn)
	{
		Array3D<T> result(*this);
		result /= arrIn;

		return result;
	}
	
	// Assignment by Division
	inline void operator/= (const Array3D& arrIn)
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = m_pArray[count]/arrIn.m_pArray[count];
		}
	}
	
	// Addition - Single value
	inline Array3D operator+ (T value)
	{
		Array3D<T> result(*this);
		result += value;

		return result;
	}
	
	// Assignment by Addition - Single value
	inline void operator+= (T value)
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = m_pArray[count]+value;
		}
	}
	
	// Addition - arrIn values
	inline Array3D operator+(const Array3D& arrIn)	
	{
		Array3D<T> result(*this);
		result += arrIn;

		return result;
	}

	// Assignment by Addition - arrIn values
	inline void operator+=(const Array3D& arrIn)	
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = m_pArray[count] + arrIn.m_pArray[count];
		}
	}
	
	// Subtraction - Single value
	inline Array3D operator- (T value)
	{
		Array3D<T> result(*this);
		result -= value;

		return result;

	}
	
	// Assignment by Subtraction - Single value
	inline void operator-= (T value)
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = m_pArray[count]-value;
		}
	}
	
	// Subtraction - arrIn values
	inline Array3D operator- (Array3D& arrIn)
	{
		Array3D<T> result(*this);
		result -= arrIn;

		return result;
	}

	// Assignment by Subtraction - arrIn values
	inline void operator-= (Array3D& arrIn)
	{
		size_t count = m_size;	
		while (count--)
		{
			m_pArray[count] = m_pArray[count]-arrIn.m_pArray[count];
		}
	}
	
	// Assignment Operator
	virtual inline const Array3D& operator= (const Array3D& right)
	{
		//avoid self assignment
		if (this != &right)
		{
			if(m_size != right.m_size)
			{
				m_X = right.m_X;
				m_Y = right.m_Y;
				m_Z = right.m_Z;
				delete [] m_pArray;
				m_pArray = new T[m_size];
			}
			
			memcpy(m_pArray, right.m_pArray, m_size*sizeof(T));
		}

		return *this;
	}

	// Set entire array to a single value
	void Set(T initialValue)
	{
		size_t count = m_size;
		while (count--)
		{
			m_pArray[count] = initialValue;
		}
	}

	typedef void SETFUNCPTR(T& arr, size_t i, size_t j, size_t k, size_t index);
	// initialize the entire array via a function that sets the value
	// takes the & of the element, the x,y,z values & the index value;
	void Set(SETFUNCPTR fp) 
	{ 
		size_t i = 0;
		size_t x;
		size_t y;
		size_t z;
		for(x = 0 ; x < m_X ; ++x)
		{
			for(y = 0 ; y < m_Y ; ++y)
			{
				for(z = 0 ; z < m_Z ; ++z)
				{
					(*fp)(m_pArray[i],x,y,z,i);
					++i;
				}
			}
		}
	}



	int GetX()          { return m_X; }
	void SetX(int setX) { m_X = setX; m_size = m_X*m_Y*m_Z;}
	int GetY()          { return m_Y; }
	void SetY(int setY) { m_Y = setY; m_size = m_X*m_Y*m_Z;}
	int GetZ()          { return m_Z; }
	void SetZ(int setZ) { m_Z = setZ; m_size = m_X*m_Y*m_Z;}
	int GetSize() { return m_size; }

protected:

	// Creates and initializes the array 
	void Initialize()
	{
		m_pArray = new T[m_size];
	}

	T* m_pArray;	 // 1D array of 3D elements
	int m_X;         // X dimension of array  
	int m_Y;         // Y dimension of array
	int m_Z;		 // Z dimension of array
	unsigned int m_size;		 // Total size of array
};
