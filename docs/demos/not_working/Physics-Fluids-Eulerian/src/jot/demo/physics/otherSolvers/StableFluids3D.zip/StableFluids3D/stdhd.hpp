#ifndef _STDHD_HPP_
#define _STDHD_HPP_

//c libraries
#define _USE_MATH_DEFINES
#include <cmath>
#include <ctime>
//#include <cstdio>
//#include <cstdlib>

//OpenGL tools
#include <GL/glew.h>
#include <GL/freeglut.h>

//c++ libraries
#include <fstream>
#include <iostream>

using namespace std;

#define _A (0x00000000) //air cell
#define _MB (0x80000000) //moving bound cell
#define _SB (0x40000000) //static bound cell
#define _SL1 (0x20000000) //surface of liquid 1 cell
#define _SL2 (0x10000000) //surface of liquid 2 cell
#define _LL1 (0x08000000) //liquid 1 cell
#define _LL2 (0x04000000) //liquid 2 cell

#define _SURFACE_TRACKING_ON
#define _RENDER
//#define _MILISECONDS

#define _32_CUBIC_GRID
//#define _64_CUBIC_GRID
//#define _128_CUBIC_GRID

#ifdef _32_CUBIC_GRID
	#define _NX 32 //number of cells in X
	#define _NY 32 //number of cells in Y
	#define _NZ 32 //number of cells in Y
#endif //_32_CUBIC_GRID

#ifdef _64_CUBIC_GRID
	#define _NX 64 //number of cells in X
	#define _NY 64 //number of cells in Y
	#define _NZ 64 //number of cells in Y
#endif //_64_CUBIC_GRID

#ifdef _128_CUBIC_GRID
	#define _NX 128 //number of cells in X
	#define _NY 128 //number of cells in Y
	#define _NZ 128 //number of cells in Y
#endif //_128_CUBIC_GRID

#define _sizeX 1.0 //size of cell in X
#define _sizeY 1.0 //size of cell in Y
#define _sizeZ 1.0 //size of cell in Z
#define _IX(x,y,z) ((x)+(_NX)*((y)+((z)*(_NY)))) //index to access the corresponding position of grid

#define FOR_EACH_CELL1\
	for(k=(NZ-1);k>=0;k--){\
	for(j=(NY-1);j>=0;j--){\
	for(i=0;i<=(NX-1);i++){

#define FOR_EACH_CELL2\
	for(k=1;k<=((g->NZ)-2);k++){\
	for(j=1;j<=((g->NY)-2);j++){\
	for(i=1;i<=((g->NX)-2);i++){

#define FOR_EACH_CELL3\
	for(k=1;k<=((g.NZ)-2);k++){\
	for(j=1;j<=((g.NY)-2);j++){\
	for(i=1;i<=((g.NX)-2);i++){

#define FOR_ALL_CELLS1\
	for(i=0;i<T_cells;i++){	

#define FOR_ALL_CELLS2\
	for(i=0;i<(g->T_cells);i++){	

#define FOR_EACH_CELL4\
	for(k=1;k<=((g->NZ)-2);k++){ z=((k-0.5f)*g->sizeZ)/((g->NZ)-2);\
	for(j=1;j<=((g->NY)-2);j++){ y=((j-0.5f)*g->sizeY)/((g->NY)-2);\
	for(i=1;i<=((g->NX)-2);i++){ x=((i-0.5f)*g->sizeX)/((g->NX)-2);

#define END_FOR_ALL_CELLS }
#define END_FOR_EACH_CELL }}}

#endif //_STDHD_HPP_