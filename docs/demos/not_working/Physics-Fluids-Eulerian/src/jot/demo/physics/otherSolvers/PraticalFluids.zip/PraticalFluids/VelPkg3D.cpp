//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// Portions of the terrain tiling and grass code, DXUT, and basic shaders were
// adapted from the PIX Workshop GDC 2007 sample source code.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Portions of the fluid simulation are based on the original work 
// "Practical Fluid Mechanics" by Mick West used with permission.
//	http://www.gamasutra.com/view/feature/1549/practical_fluid_dynamics_part_1.php
//	http://www.gamasutra.com/view/feature/1615/practical_fluid_dynamics_part_2.php
//	http://cowboyprogramming.com/2008/04/01/practical-fluid-mechanics/
//
// Portions of the volumetric shader used with permission.
// "Real-Time Volume Graphics", Engel et. al. Ch 7, Fig. 7.1
// Copyright 2006 A K Peters Ltd.
//	http://www.real-time-volume-graphics.org/
//-------------------------------------------------------------------------------------

#include "VelPkg3D.h"


VelPkg3D::VelPkg3D(int x, int y, int z) : m_X(x), m_Y(y), m_Z(z)
{
	mp_prop = new FluidProperties();
	mp_prop->diffusion = 0.0f;
	mp_prop->advection = 0.0f;
	mp_prop->force     = 0.0f;
	mp_prop->decay  = 0.0f;
	mp_sourceX = new Fluid3D(x,y,z);
	mp_destX   = new Fluid3D(x,y,z);
	mp_sourceY = new Fluid3D(x,y,z);
	mp_destY   = new Fluid3D(x,y,z);
	mp_sourceZ = new Fluid3D(x,y,z);
	mp_destZ   = new Fluid3D(x,y,z);
}


VelPkg3D& VelPkg3D::operator= (const VelPkg3D& right)
{
	if (this != &right)
	{
		delete mp_prop;
		delete mp_sourceX;
		delete mp_destX;
		delete mp_sourceY;
		delete mp_destY;
		delete mp_sourceZ;
		delete mp_destZ;
		mp_sourceX = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_destX = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_sourceY = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_destY = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_sourceZ = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_destZ = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_prop = new FluidProperties();
		mp_prop->diffusion = right.mp_prop->diffusion;
		mp_prop->advection = right.mp_prop->advection;
		mp_prop->force = right.mp_prop->force;
		mp_prop->decay = right.mp_prop->decay;
	}
	return *this;
}


void VelPkg3D::SwapLocationsX()
{
	Fluid3D *temp = mp_sourceX;
	mp_sourceX = mp_destX;
	mp_destX = temp;
}


void VelPkg3D::SwapLocationsY()
{
	Fluid3D *temp = mp_sourceY;
	mp_sourceY = mp_destY;
	mp_destY = temp;
}


void VelPkg3D::SwapLocationsZ()
{
	Fluid3D *temp = mp_sourceZ;
	mp_sourceZ = mp_destZ;
	mp_destZ = temp;
}


void VelPkg3D::Reset(float v)
{
	mp_sourceX->Set(v);
	mp_destX->Set(v);
	mp_sourceY->Set(v);
	mp_destY->Set(v);
	mp_sourceZ->Set(v);
	mp_destZ->Set(v);

}


VelPkg3D::~VelPkg3D()
{
	SAFE_DELETE(mp_prop);
	SAFE_DELETE(mp_sourceX);
	SAFE_DELETE(mp_destX);
	SAFE_DELETE(mp_sourceY);
	SAFE_DELETE(mp_destY);
	SAFE_DELETE(mp_sourceZ);
	SAFE_DELETE(mp_destZ);
}


// Accessor methods
Fluid3D* VelPkg3D::SourceX()          { return mp_sourceX; }
Fluid3D* VelPkg3D::DestinationX()      { return mp_destX; }
Fluid3D* VelPkg3D::SourceY()          { return mp_sourceY; }
Fluid3D* VelPkg3D::DestinationY()      { return mp_destY; }
Fluid3D* VelPkg3D::SourceZ()          { return mp_sourceZ; }
Fluid3D* VelPkg3D::DestinationZ()      { return mp_destZ; }
FluidProperties* VelPkg3D::Properties() { return mp_prop; }

