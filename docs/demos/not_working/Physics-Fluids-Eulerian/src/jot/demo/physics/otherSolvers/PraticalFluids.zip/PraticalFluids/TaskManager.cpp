//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// Portions of the terrain tiling and grass code, DXUT, and basic shaders were
// adapted from the PIX Workshop GDC 2007 sample source code.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Portions of the fluid simulation are based on the original work 
// "Practical Fluid Mechanics" by Mick West used with permission.
//	http://www.gamasutra.com/view/feature/1549/practical_fluid_dynamics_part_1.php
//	http://www.gamasutra.com/view/feature/1615/practical_fluid_dynamics_part_2.php
//	http://cowboyprogramming.com/2008/04/01/practical-fluid-mechanics/
//
// Portions of the volumetric shader used with permission.
// "Real-Time Volume Graphics", Engel et. al. Ch 7, Fig. 7.1
// Copyright 2006 A K Peters Ltd.
//	http://www.real-time-volume-graphics.org/
//-------------------------------------------------------------------------------------

#pragma warning(disable:4996) // For deprecated mbstowcs calls in TBB
#include "TaskManager.h"

#include <tbb/task_scheduler_init.h>
#include <tbb/task.h>

TaskManager *TaskManager::sm_pTaskManager = NULL;

TaskManager *TaskManager::getTaskManager()
{
    if(sm_pTaskManager == NULL)
    {
        sm_pTaskManager = new TaskManager();
    }
    
    return sm_pTaskManager;
}

TaskManager::JobResult::JobResult(tbb::task *pTask):
    m_pTask(pTask),
    m_bReady(false),
    m_tMutex()
{}

TaskManager::JobResult::~JobResult()
{
    if(m_pTask != NULL)
    {
        waitUntilDone();
    }
}

void TaskManager::JobResult::waitUntilDone()
{
    if(m_pTask != NULL)
    {
        // Lock up access to one-at-a-time
        tbb::spin_mutex::scoped_lock(m_tMutex);
        if(m_pTask != NULL)
        {
            m_pTask->wait_for_all();
            IASSERT(m_bReady);
            m_pTask->destroy(*m_pTask);
            m_pTask = NULL;
        }
    }
}

tbb::task *TaskManager::JobTask::execute()
{
    IASSERT(m_pResult != NULL);
    m_tFunc(m_pParam);
    m_pResult->markAsReady();
    
    return NULL;
}

TaskManager::TaskManager():
    m_pTaskScheduler(NULL)
{}

void TaskManager::init()
{
	m_pTaskScheduler = new tbb::task_scheduler_init();
}

unsigned int TaskManager::getThreadCount()
{
    // Return the number of new threads created by TBB specifically, don't include the primary thread in this count
    return (tbb::task_scheduler_init::default_num_threads() - 1);
}

TaskManager::JobResult *TaskManager::submitJob(JobFunction tFunc, void *pParam)
{
    tbb::task *pParentTask = new(tbb::task::allocate_root()) tbb::empty_task();
    JobResult *pResult = new JobResult(pParentTask);
    JobTask *pJobTask = new(pParentTask->allocate_child()) JobTask(tFunc, pParam, pResult);
    
    pParentTask->set_ref_count(2);
    pParentTask->spawn(*pJobTask);

    return pResult;
}

void TaskManager::shutdown()
{
    if(m_pTaskScheduler)
    {
        delete m_pTaskScheduler;
        m_pTaskScheduler = NULL;
    }
}