#ifndef _CSOLVER_HPP_
#define _CSOLVER_HPP_

#define _VELOCITY_DIFFUSION_ITERS 4 //13
#define _VELOCITY_PROJECTION_ITERS 4 //13
#define _DENSITY_DIFFUSION_ITERS 4 //13

#define _DIFFUSION_SOLVER 1
#define _PROJECTION_SOLVER 1

class CSOLVER
{
	private:
		static void dens_step(CGRID *g,CSOLID_OBJECT *s_obj,float dt);
		static void vel_step(CGRID *g,CSOLID_OBJECT *s_obj,float dt);
		static void add_source(CGRID *g,float *x,float *s,float dt);
		static void diffuse(CGRID *g,CSOLID_OBJECT *s_obj,float *x,float *x0,float dt,long iters,long b);
		static void project(CGRID *g,CSOLID_OBJECT *s_obj,float *vx,float *vy,float *vz,float *p,float *div);
		static void advect(CGRID *g,CSOLID_OBJECT *s_obj,float *x,float *x0,float *vx,float *vy,float *vz,float dt,long b);
		static void linear_solver(CGRID *g,CSOLID_OBJECT *s_obj,float *x,float *x0,float a,float iter,long iters,long b,long solver);

	public:
		static void _fluid_simulator(CGRID *g,CSOLID_OBJECT *s_obj,float dt);
};

#endif //_CSOLVER_HPP_