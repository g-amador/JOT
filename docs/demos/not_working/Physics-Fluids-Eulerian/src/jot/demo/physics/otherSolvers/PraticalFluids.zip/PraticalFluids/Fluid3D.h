//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// Portions of the terrain tiling and grass code, DXUT, and basic shaders were
// adapted from the PIX Workshop GDC 2007 sample source code.
// Copyright(c) Microsoft Corporation. All rights reserved.
//
// Portions of the fluid simulation are based on the original work 
// "Practical Fluid Mechanics" by Mick West used with permission.
//	http://www.gamasutra.com/view/feature/1549/practical_fluid_dynamics_part_1.php
//	http://www.gamasutra.com/view/feature/1615/practical_fluid_dynamics_part_2.php
//	http://cowboyprogramming.com/2008/04/01/practical-fluid-mechanics/
//
// Portions of the volumetric shader used with permission.
// "Real-Time Volume Graphics", Engel et. al. Ch 7, Fig. 7.1
// Copyright 2006 A K Peters Ltd.
//	http://www.real-time-volume-graphics.org/
//-------------------------------------------------------------------------------------


#pragma once

#include "Array3D.h"
#include <cmath>
#include <assert.h>

// Adds fluid specific functions to class Array3D
class Fluid3D : public Array3D<float>
{
public:

	// Constructor - Sets size of array
	Fluid3D(int x, int y, int z);

	// When a point is advected it will land in Add fractions of value to the 4 neighboring grid 
	// points of the floating point coordinates
	void DistributeFloatingPoint(float x, float y, float z, float value); 
};

