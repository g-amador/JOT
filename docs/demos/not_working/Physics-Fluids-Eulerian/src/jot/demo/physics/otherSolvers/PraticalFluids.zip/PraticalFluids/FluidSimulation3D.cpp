//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// Portions of the terrain tiling and grass code, DXUT, and basic shaders were
// adapted from the PIX Workshop GDC 2007 sample source code.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Portions of the fluid simulation are based on the original work 
// "Practical Fluid Mechanics" by Mick West used with permission.
//	http://www.gamasutra.com/view/feature/1549/practical_fluid_dynamics_part_1.php
//	http://www.gamasutra.com/view/feature/1615/practical_fluid_dynamics_part_2.php
//	http://cowboyprogramming.com/2008/04/01/practical-fluid-mechanics/
//
// Portions of the volumetric shader used with permission.
// "Real-Time Volume Graphics", Engel et. al. Ch 7, Fig. 7.1
// Copyright 2006 A K Peters Ltd.
//	http://www.real-time-volume-graphics.org/
//-------------------------------------------------------------------------------------

#pragma warning(disable:4996) // For deprecated mbstowcs calls in TBB

#include "FluidSimulation3D.h"


FluidSimulation3D::FluidSimulation3D(int xSize, int ySize, int zSize, float dt) 
: m_dt(dt), m_w(xSize), m_h(ySize),m_d(zSize),m_diffusionIter(1), m_vorticity(0.0), m_pressureAccel(0.0)
{
	m_curl = new Fluid3D(xSize, ySize, zSize);
	mp_velocity = new VelPkg3D(xSize, ySize, zSize);
	mp_pressure = new FluidPkg3D(xSize, ySize, zSize);
	mp_ink = new FluidPkg3D(xSize, ySize, zSize);
	mp_heat = new FluidPkg3D(xSize, ySize, zSize);

#if RUN_MULTITHREADED
	// TBB contexts
	m_diffusionContext = new ApplyDiffusion();
	m_rAdvectionContext = new ApplyReverseAdvection();
	m_fAdvectionContext = new ApplyForwardAdvection();
#endif

	Reset();
}


FluidSimulation3D::~FluidSimulation3D()
{
#if RUN_MULTITHREADED
	SAFE_DELETE(m_diffusionContext);
	SAFE_DELETE(m_rAdvectionContext);
	SAFE_DELETE(m_fAdvectionContext);
#endif

	SAFE_DELETE(m_curl);
	SAFE_DELETE(mp_pressure);
	SAFE_DELETE(mp_velocity);
	SAFE_DELETE(mp_ink);
	SAFE_DELETE(mp_heat);
}


// Update is called every frame or as specified in the max desired updates per second GUI slider
void FluidSimulation3D::Update(unsigned int numThreads)
{
	m_numThreads = numThreads;
	IASSERT(m_numThreads > 0);

	UpdateDiffusion();
	UpdateForces();
	UpdateAdvection();
}


// Apply diffusion across the grids
void FluidSimulation3D::UpdateDiffusion()
{
	__ITT_EVENT_START(evt_UpdateDiffusion);

	// Skip diffusion if disabled
	if (mp_velocity->Properties()->diffusion != 0.0f)
	{
		float scaledDiffusion = mp_velocity->Properties()->diffusion / (float)m_diffusionIter;

		// Diffusion of Velocity
		for (int i=0;i<m_diffusionIter;i++)
		{
			Diffusion(mp_velocity->SourceX(), mp_velocity->DestinationX(), scaledDiffusion);
			mp_velocity->SwapLocationsX();
			Diffusion(mp_velocity->SourceY(), mp_velocity->DestinationY(), scaledDiffusion);
			mp_velocity->SwapLocationsY();
			Diffusion(mp_velocity->SourceZ(), mp_velocity->DestinationZ(), scaledDiffusion);
			mp_velocity->SwapLocationsZ();
		}

		// Diffusion of Pressure
		for (int i=0;i<m_diffusionIter;i++)
		{
			Diffusion(mp_pressure->Source(), mp_pressure->Destination(), mp_pressure->Properties()->diffusion /(float)m_diffusionIter);
			mp_pressure->SwapLocations();
		}

		// Diffusion of Heat
		for (int i=0;i<m_diffusionIter;i++)
		{
			Diffusion(mp_heat->Source(), mp_heat->Destination(), mp_heat->Properties()->diffusion /(float)m_diffusionIter);
			mp_heat->SwapLocations();
		}

		// Diffusion of Ink
		for (int i=0;i<m_diffusionIter;i++)
		{
			Diffusion(mp_ink->Source(), mp_ink->Destination(), mp_ink->Properties()->diffusion /(float)m_diffusionIter);
			mp_ink->SwapLocations();
		}

	}

	__ITT_EVENT_END(evt_UpdateDiffusion);

}


// Apply the effects of heat to the velocity grid
void FluidSimulation3D::Heat(float scale)
{
	float force = m_dt * scale ; 

	*mp_velocity->DestinationX() = *mp_velocity->SourceX();
	*mp_velocity->DestinationY() = *mp_velocity->SourceY();
	*mp_velocity->DestinationZ() = *mp_velocity->SourceZ(); 

	for (int x = 0; x < m_w-1; x++)
	{
		for (int y = 0; y < m_h-1; y++)
		{
			for (int z = 0; z < m_d-1; z++)
			{
				// Pressure differential between points to get an accelleration force.
				float force_x =  mp_heat->Source()->element(x,y,z)   - mp_heat->Source()->element(x+1,y,z);  
				float force_y =  mp_heat->Source()->element(x,y,z)   - mp_heat->Source()->element(x,y+1,z);  
				float force_z =  mp_heat->Source()->element(x,y,z)   - mp_heat->Source()->element(x,y,z+1);  

				// Use the acceleration force to move the velocity field in the appropriate direction. 
				// Ex. If an area of high pressure exists the acceleration force will turn the velocity field
				// away from this area
				mp_velocity->DestinationX()->element(x,y,z)     +=  force * force_x;
				mp_velocity->DestinationX()->element(x+1,y,z)   +=  force * force_x;

				mp_velocity->DestinationY()->element(x,y,z)     +=  force * force_y;
				mp_velocity->DestinationY()->element(x,y+1,z)	+=  force * force_y;

				mp_velocity->DestinationZ()->element(x,y,z)     +=  force * force_z;
				mp_velocity->DestinationZ()->element(x,y,z+1)	+=  force * force_z;
			}
		}
	}

	mp_velocity->SwapLocationsX();
	mp_velocity->SwapLocationsY();
	mp_velocity->SwapLocationsZ();
}


// Apply forces across the grids
void FluidSimulation3D::UpdateForces()
{
	__ITT_EVENT_START(evt_UpdateForces);

	// Apply upwards force on velocity from ink rising under its own steam 
	if (mp_ink->Properties()->force != 0.0f)
	{
		*mp_velocity->SourceY() +=  *mp_ink->Source() * mp_ink->Properties()->force;
	}

	// Apply upwards force on velocity field from heat
	if (mp_heat->Properties()->force != 0.0f)
	{
		Heat(mp_heat->Properties()->force);

		if (mp_heat->Properties()->decay != 0.0f)
		{
			ExponentialDecay(mp_heat->Source(), mp_heat->Properties()->decay);
		}
	}

	// Apply dampening force on velocity due to viscosity
	if (mp_velocity->Properties()->decay != 0.0f)
	{
		ExponentialDecay(mp_velocity->SourceX(), mp_velocity->Properties()->decay);
		ExponentialDecay(mp_velocity->SourceY(), mp_velocity->Properties()->decay);
		ExponentialDecay(mp_velocity->SourceZ(), mp_velocity->Properties()->decay);
	}

	// Apply equilibrium force on pressure for mass conservation
	if (m_pressureAccel != 0.0f)
	{
		PressureAcceleration(m_pressureAccel);
	}

	// Apply curl force on vorticies to prevent artificial dampening
	if (m_vorticity != 0.0f)
	{
		VorticityConfinement(m_vorticity);
	}

	__ITT_EVENT_END(evt_UpdateForces);

}


// Apply advection across the grids
void FluidSimulation3D::UpdateAdvection()
{
	__ITT_EVENT_START(evt_UpdateAdvection);

	float avg_dimension = (m_w+m_h+m_d) / 3.0f;
	const float std_dimension = 100.0f;	

	// Change advection scale depending on grid size. Smaller grids means larger cells, so scale should be smaller.
	// Average dimension size of std_dimension value (100) equals an advection_scale of 1
	float advection_scale = avg_dimension / std_dimension;

	mp_ink->Destination()->Set(1.0f);

	// Advect the ink
	ForwardAdvection(mp_ink->Source(), mp_ink->Destination(), mp_ink->Properties()->advection * advection_scale);
	mp_ink->SwapLocations();
	ReverseAdvection(mp_ink->Source(), mp_ink->Destination(), mp_ink->Properties()->advection * advection_scale);
	mp_ink->SwapLocations();

	// Only advect the heat if it is applying a force
	if(EqualToZero(mp_heat->Properties()->force))
	{
		ForwardAdvection(mp_heat->Source(), mp_heat->Destination(), mp_heat->Properties()->advection * advection_scale);
		mp_heat->SwapLocations();
		ReverseAdvection(mp_heat->Source(), mp_heat->Destination(), mp_heat->Properties()->advection * advection_scale);
		mp_heat->SwapLocations();
	}

	// Advection order makes significant differences
	// Advecting pressure first leads to self-maintaining waves and ripple artifacts
	// Advecting velocity first naturally dissipates the waves

	// Advect Velocity
	ForwardAdvection(mp_velocity->SourceX(), mp_velocity->DestinationX(), mp_velocity->Properties()->advection * advection_scale);
	ForwardAdvection(mp_velocity->SourceY(), mp_velocity->DestinationY(), mp_velocity->Properties()->advection * advection_scale);
	ForwardAdvection(mp_velocity->SourceZ(), mp_velocity->DestinationZ(), mp_velocity->Properties()->advection * advection_scale);

	ReverseSignedAdvection(mp_velocity, advection_scale); 

	// Take care of boundries
	InvertVelocityEdges();

	// Advect Pressure. Represents compressible fluid (e.g. air)
	ForwardAdvection(mp_pressure->Source(), mp_pressure->Destination(), mp_pressure->Properties()->advection * advection_scale);
	mp_pressure->SwapLocations();
	ReverseAdvection(mp_pressure->Source(), mp_pressure->Destination(), mp_pressure->Properties()->advection * advection_scale);
	mp_pressure->SwapLocations();

	__ITT_EVENT_END(evt_UpdateAdvection);
}


#if RUN_MULTITHREADED
// These methods invoke the TBB parallel_for method.  
// The original serial methods may be invoked with RUN_MULTITHREADED 0
void FluidSimulation3D::ForwardAdvection(Fluid3D *src, Fluid3D *dest, float scale)
{
	float force = m_dt * scale ;
	unsigned int uBegin = 0;
	unsigned int uEnd = m_w * m_h * m_d;
	unsigned int uGrainSize = (uEnd / m_numThreads) + 1;

	*dest = *src;

	if (force == 0.0f)
	{
		return;
	}

	m_fAdvectionContext->Set(src, dest, mp_velocity, force, m_w, m_h, m_d, m_bBoundaryCondition);
	parallel_for(tbb::blocked_range<unsigned int>(uBegin, uEnd, uGrainSize), 
		*m_fAdvectionContext);
}
void FluidSimulation3D::ReverseAdvection(Fluid3D *src, Fluid3D *dest, float scale)
{
	float force = m_dt * scale; // distance to advect
	unsigned int uBegin = 0;
	unsigned int uEnd = m_w * m_h * m_d;
	unsigned int uGrainSize = (uEnd / m_numThreads) + 1;

	// Copy source to destination as reverse advection results in adding/subtracing not moving
	*dest = *src;

	// we need to zero out the fractions 
	Array3D<int> FromSource_xA(m_w, m_h, m_d, -1);  // The new X coordinate after advection stored in x,y,z where x,y,z,z is the original source point
	Array3D<int> FromSource_yA(m_w, m_h, m_d, -1);  // The new Y coordinate after advection stored in x,y,z where x,y,z is the original source point
	Array3D<int> FromSource_zA(m_w, m_h, m_d, -1);  // The new Z coordinate after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_A(m_w, m_h, m_d);		  // The value of A after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_B(m_w, m_h, m_d);		  // The value of B after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_C(m_w, m_h, m_d);       // The value of C after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_D(m_w, m_h, m_d);       // The value of D after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_E(m_w, m_h, m_d);		  // The value of E after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_F(m_w, m_h, m_d);		  // The value of F after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_G(m_w, m_h, m_d);       // The value of G after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_H(m_w, m_h, m_d);       // The value of H after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> TotalDestValue(m_w, m_h, m_d);     // The total accumulated value after advection stored in x,y,z where x,y,z is the destination point

	m_rAdvectionContext->Set(src, dest, mp_velocity, &FromSource_xA, &FromSource_yA, &FromSource_zA, &FromSource_A, &FromSource_B, &FromSource_C, &FromSource_D, &FromSource_E, &FromSource_F, &FromSource_G, &FromSource_H, &TotalDestValue, force, m_w, m_h, m_d, true, m_bBoundaryCondition);
	parallel_for(tbb::blocked_range<unsigned int>(uBegin, uEnd, uGrainSize), 
		*m_rAdvectionContext);

	m_rAdvectionContext->Set(src, dest, mp_velocity, &FromSource_xA, &FromSource_yA, &FromSource_zA, &FromSource_A, &FromSource_B, &FromSource_C, &FromSource_D, &FromSource_E, &FromSource_F, &FromSource_G, &FromSource_H, &TotalDestValue, force, m_w, m_h, m_d, false, m_bBoundaryCondition);
	parallel_for(tbb::blocked_range<unsigned int>(uBegin, uEnd, uGrainSize), 
		*m_rAdvectionContext);
}


void FluidSimulation3D::Diffusion(Fluid3D *p_in, Fluid3D *p_out, const float scale)
{
	float force = m_dt * scale ; // distance to advect

	unsigned int uBegin = 0;
	unsigned int uEnd = p_in->GetSize();
	unsigned int uGrainSize = (uEnd / m_numThreads) + 1;

	// Iterate through cells along the top and bottom surfaces (not including corners).  5 neighbors total. 
	for (int x = 1; x < m_w-1; x++)
	{
		for (int z = 1; z < m_d-1; z++)
		{
			p_out->element(x,0,z) = p_in->element(x,0,z) + force * 
				(p_in->element(x-1,0,z) + 
				p_in->element(x+1,0,z) + 
				p_in->element(x,0,z-1) + 
				p_in->element(x,0,z+1) + 
				p_in->element(x,1,z) - 5.0f * p_in->element(x,0,z));
			p_out->element(x,m_h-1,z) = p_in->element(x,m_h-1,z) + force * 
				(p_in->element(x-1,m_h-1,z) + 
				p_in->element(x+1,m_h-1,z) + 
				p_in->element(x,m_h-1,z-1) + 
				p_in->element(x,m_h-1,z+1) + 
				p_in->element(x,m_h-2,z) - 5.0f * p_in->element(x,m_h-1,z));
		}
	}
	// Iterate through cells along the left and right surfaces (not including corners).  5 neighbors total. 
	for (int y = 1; y < m_h-1; y++)
	{
		for (int z = 1; z < m_d-1; z++)
		{
			p_out->element(0,y,z) = p_in->element(0,y,z) + force * 
				(p_in->element(0,y-1,z) + 
				p_in->element(0,y+1,z) + 
				p_in->element(0,y,z-1) + 
				p_in->element(0,y,z+1) + 
				p_in->element(1,y,z) - 5.0f * p_in->element(0,y,z));
			p_out->element(m_w-1,y,z) = p_in->element(m_w-1,y,z) + force * 
				(p_in->element(m_w-1,y-1,z) + 
				p_in->element(m_w-1,y+1,z) + 
				p_in->element(m_w-1,y,z-1) + 
				p_in->element(m_w-1,y,z+1) + 
				p_in->element(m_w-2,y,z) - 5.0f * p_in->element(m_w-1,y,z));
		}
	}

	// Iterate through cells along the front and back surfaces (not including corners).  5 neighbors total. 
	for (int x = 1; x < m_w-1; x++)
	{
		for (int y = 1; y < m_h-1; y++)
		{
			p_out->element(x,y,0) = p_in->element(x,y,0) + force * 
				(p_in->element(x,y-1,0) + 
				p_in->element(x,y+1,0) + 
				p_in->element(x-1,y,0) + 
				p_in->element(x+1,y,0) + 
				p_in->element(x,y,1) - 5.0f * p_in->element(x,y,0));
			p_out->element(x,y,m_d-1) = p_in->element(x,y,m_d-1) + force * 
				(p_in->element(x,y-1,m_d-1) + 
				p_in->element(x,y+1,m_d-1) + 
				p_in->element(x-1,y,m_d-1) + 
				p_in->element(x+1,y,m_d-1) + 
				p_in->element(x,y,m_d-2) - 5.0f * p_in->element(x,y,m_d-1));
		}
	}

	// Iterate through cells along the x axis.  4 neighbors total. 
	for (int x = 1; x < m_w-1; x++)
	{
		p_out->element(x,0,0) = p_in->element(x,0,0) + force * 
			(p_in->element(x-1,0,0) + 
			p_in->element(x+1,0,0) + 
			p_in->element(x,0,1) + 
			p_in->element(x,1,0) - 4.0f * p_in->element(x,0,0));
		p_out->element(x,m_h-1,0) = p_in->element(x,m_h-1,0) + force * 
			(p_in->element(x-1,m_h-1,0) + 
			p_in->element(x+1,m_h-1,0) + 
			p_in->element(x,m_h-2,0) + 
			p_in->element(x,m_h-1,1) - 4.0f * p_in->element(x,m_h-1,0));
		p_out->element(x,0,m_d-1) = p_in->element(x,0,m_d-1) + force * 
			(p_in->element(x-1,0,m_d-1) + 
			p_in->element(x+1,0,m_d-1) + 
			p_in->element(x,0,m_d-2) + 
			p_in->element(x,1,m_d-1) - 4.0f * p_in->element(x,0,m_d-1));
		p_out->element(x,m_h-1,m_d-1) = p_in->element(x,m_h-1,m_d-1) + force * 
			(p_in->element(x-1,m_h-1,m_d-1) + 
			p_in->element(x+1,m_h-1,m_d-1) + 
			p_in->element(x,m_h-2,m_d-1) + 
			p_in->element(x,m_h-1,m_d-2) - 4.0f * p_in->element(x,m_h-1,m_d-1));
	}

	// Iterate through cells along the y axis.  4 neighbors total. 
	for (int y = 1; y < m_h-1; y++)
	{
		p_out->element(0,y,0) = p_in->element(0,y,0) + force * 
			(p_in->element(0,y-1,0) + 
			p_in->element(0,y+1,0) + 
			p_in->element(0,y,1) + 
			p_in->element(1,y,0) - 4.0f * p_in->element(0,y,0));
		p_out->element(m_w-1,y,0) = p_in->element(m_w-1,y,0) + force * 
			(p_in->element(m_w-1,y-1,0) + 
			p_in->element(m_w-1,y+1,0) + 
			p_in->element(m_w-1,y,1) + 
			p_in->element(m_w-2,y,0) - 4.0f * p_in->element(m_w-1,y,0));
		p_out->element(0,y,m_d-1) = p_in->element(0,y,m_d-1) + force * 
			(p_in->element(0,y-1,m_d-1) + 
			p_in->element(0,y+1,m_d-1) + 
			p_in->element(0,y,m_d-2) + 
			p_in->element(1,y,m_d-1) - 4.0f * p_in->element(0,y,m_d-1));
		p_out->element(m_w-1,y,m_d-1) = p_in->element(m_w-1,y,m_d-1) + force * 
			(p_in->element(m_w-1,y-1,m_d-1) + 
			p_in->element(m_w-1,y+1,m_d-1) + 
			p_in->element(m_w-1,y,m_d-2) + 
			p_in->element(m_w-2,y,m_d-1) - 4.0f * p_in->element(m_w-1,y,m_d-1));
	}

	// Iterate through cells along the z axis.  4 neighbors total. 
	for (int z = 1; z < m_d-1; z++)
	{
		p_out->element(0,0,z) = p_in->element(0,0,z) + force * 
			(p_in->element(0,0,z-1) + 
			p_in->element(0,0,z+1) + 
			p_in->element(1,0,z) + 
			p_in->element(0,1,z) - 4.0f * p_in->element(0,0,z));
		p_out->element(m_w-1,0,z) = p_in->element(m_w-1,0,z) + force * 
			(p_in->element(m_w-1,0,z-1) + 
			p_in->element(m_w-1,0,z+1) + 
			p_in->element(m_w-2,0,z) + 
			p_in->element(m_w-1,1,z) - 4.0f * p_in->element(m_w-1,0,z));
		p_out->element(0,m_h-1,z) = p_in->element(0,m_h-1,z) + force * 
			(p_in->element(0,m_h-1,z-1) + 
			p_in->element(0,m_h-1,z+1) + 
			p_in->element(1,m_h-1,z) + 
			p_in->element(0,m_h-2,z) - 4.0f * p_in->element(0,m_h-1,z));
		p_out->element(m_w-1,m_h-1,z) = p_in->element(m_w-1,m_h-1,z) + force * 
			(p_in->element(m_w-1,m_h-1,z-1) + 
			p_in->element(m_w-1,m_h-1,z+1) + 
			p_in->element(m_w-2,m_h-1,z) + 
			p_in->element(m_w-1,m_h-2,z) - 4.0f * p_in->element(m_w-1,m_h-1,z));
	}

	// Diffuse the last 8 corner cells.  3 neighbors total. 
	p_out->element(0,0,0) = p_in->element(0,0,0) + force * 
		(p_in->element(1,0,0) + 
		p_in->element(0,1,0) + 
		p_in->element(0,0,1) - 3.0f * p_in->element(0,0,0));
	p_out->element(m_w-1,0,0) = p_in->element(m_w-1,0,0) + force * 
		(p_in->element(m_w-2,0,0) + 
		p_in->element(m_w-1,1,0) + 
		p_in->element(m_w-1,0,1) - 3.0f * p_in->element(m_w-1,0,0));
	p_out->element(0,m_h-1,0) = p_in->element(0,m_h-1,0) + force * 
		(p_in->element(1,m_h-1,0) + 
		p_in->element(0,m_h-2,0) + 
		p_in->element(0,m_h-1,1) - 3.0f * p_in->element(0,m_h-1,0));
	p_out->element(m_w-1,m_h-1,0) = p_in->element(m_w-1,m_h-1,0) + force * 
		(p_in->element(m_w-2,m_h-1,0) +
		p_in->element(m_w-1,m_h-2,0) +
		p_in->element(m_w-1,m_h-1,1) - 3.0f * p_in->element(m_w-1,m_h-1,0));
	p_out->element(0,0,m_d-1) = p_in->element(0,0,m_d-1) + force * 
		(p_in->element(1,0,m_d-1) + 
		p_in->element(0,1,m_d-1) + 
		p_in->element(0,0,m_d-2) - 3.0f * p_in->element(0,0,m_d-1));
	p_out->element(m_w-1,0,m_d-1) = p_in->element(m_w-1,0,m_d-1) + force * 
		(p_in->element(m_w-2,0,m_d-1) + 
		p_in->element(m_w-1,1,m_d-1) + 
		p_in->element(m_w-1,0,m_d-2) - 3.0f * p_in->element(m_w-1,0,m_d-1));
	p_out->element(0,m_h-1,m_d-1) = p_in->element(0,m_h-1,m_d-1) + force * 
		(p_in->element(1,m_h-1,m_d-1) + 
		p_in->element(0,m_h-2,m_d-1) + 
		p_in->element(0,m_h-1,m_d-2) - 3.0f * p_in->element(0,m_h-1,m_d-1));
	p_out->element(m_w-1,m_h-1,m_d-1) = p_in->element(m_w-1,m_h-1,m_d-1) + force * 
		(p_in->element(m_w-2,m_h-1,m_d-1) + 
		p_in->element(m_w-1,m_h-2,m_d-1) + 
		p_in->element(m_w-1,m_h-1,m_d-2) - 3.0f * p_in->element(m_w-1,m_h-1,m_d-1));

	m_diffusionContext->Set(p_in, p_out, m_dt, force, m_w, m_h, m_d);
	parallel_for(tbb::blocked_range<unsigned int>(uBegin, uEnd, uGrainSize), 
		*m_diffusionContext);
}
#else
void FluidSimulation3D::ForwardAdvection(Fluid3D *p_in, Fluid3D *p_out, float scale)
{
	float force = m_dt * scale ; // distance to advect
	float vx, vy, vz;            // velocity values of the current x,y,z locations
	float x1, y1, z1;			 // x, y, z locations after advection
	int   x1A, y1A, z1A;		 // x, y, z locations of top-left-back grid point (A) after advection
	float fx1, fy1, fz1;		 // fractional remainders of x1, y1, z1
	float source_value;			 // original source value
	float A,                     // top-left-back grid point value after advection
		B,					 // top-right-back grid point value after advection
		C,                     // bottom-left-back grid point value after advection
		D,					 // bottom-right-back grid point value after advection
		E,                     // top-left-front grid point value after advection
		F,					 // top-right-front grid point value after advection
		G,                     // bottom-left-front grid point value after advection
		H;					 // bottom-right-front grid point value after advection

	// 
	//    A_________B
	//    |\        |\
	//    | \E______|_\F
	//    |  |      |  |
	//	  |  |      |  |
	//    C--|------D  |
	//     \ |       \ |
	//      \|G_______\H
	//

	// Copy source to destination as forward advection results in adding/subtracing not moving
	*p_out = *p_in;

	if (force == 0.0f)
	{
		return;
	}

	// This can easily be threaded as the input array is independent from the output array
	for (int x = 0; x < m_w; x++)
	{
		for (int y = 0; y < m_h; y++)
		{
			for (int z = 0; z < m_d; z++)
			{
				vx = mp_velocity->SourceX()->element(x,y,z);
				vy = mp_velocity->SourceY()->element(x,y,z);
				vz = mp_velocity->SourceZ()->element(x,y,z);
				if (!EqualToZero(vx) || !EqualToZero(vy) || !EqualToZero(vz))
				{
					// Find the floating point location of the forward advection
					x1 = x + vx * force;
					y1 = y + vy * force;
					z1 = z + vz * force;

					// Check for and correct boundary collisions
					Collide(x1,y1,z1);

					// Find the nearest top-left integer grid point of the advection 
					x1A = (int)x1;
					y1A = (int)y1;
					z1A = (int)z1;

					// Store the fractional parts
					fx1 = x1-x1A;
					fy1 = y1-y1A;
					fz1 = z1-z1A;

					// The floating point location after forward advection (x1,y1,z1) will land within an 8 point cube (A,B,C,D,E,F,G,H).
					// Distribute the value of the source point among the destination grid points using bilinear interoplation.
					// Subtract the total value given to the destination grid points from the source point.


					// Pull source value from the unmodified p_in
					source_value = p_in->element(x,y,z);

					// Bilinear interpolation
					A = (1.0f-fz1)*(1.0f-fy1)*(1.0f-fx1) * source_value;
					B = (1.0f-fz1)*(1.0f-fy1)*(fx1)      * source_value;
					C = (1.0f-fz1)*(fy1)     *(1.0f-fx1) * source_value;
					D = (1.0f-fz1)*(fy1)     *(fx1)      * source_value;
					E = (fz1)     *(1.0f-fy1)*(1.0f-fx1) * source_value;
					F = (fz1)     *(1.0f-fy1)*(fx1)      * source_value;
					G = (fz1)     *(fy1)     *(1.0f-fx1) * source_value;
					H = (fz1)     *(fy1)     *(fx1)      * source_value;

					// Add A,B,C,D,E,F,G,H to the eight destination cells
					p_out->element(x1A, y1A, z1A)     	+= A;
					p_out->element(x1A+1, y1A, z1A)   	+= B;
					p_out->element(x1A, y1A+1, z1A)   	+= C;
					p_out->element(x1A+1, y1A+1, z1A)	+= D;
					p_out->element(x1A, y1A, z1A+1)    	+= E;
					p_out->element(x1A+1, y1A, z1A+1)  	+= F;
					p_out->element(x1A, y1A+1, z1A+1)  	+= G;
					p_out->element(x1A+1, y1A+1, z1A+1)	+= H;

					// Subtract A-H from source for mass conservation
					p_out->element(x,y,z) -= (A+B+C+D+E+F+G+H);
				}
			}
		}
	}
}

void FluidSimulation3D::ReverseAdvection(Fluid3D *p_in, Fluid3D *p_out, float scale)
{
	float force = m_dt * scale ; // distance to advect
	float vx, vy, vz;            // velocity values of the current x,y,z locations
	float x1, y1, z1;			 // x, y, z locations after advection
	int   x1A, y1A, z1A;		 // x, y, z locations of top-left-back grid point (A) after advection
	float fx1, fy1, fz1;		 // fractional remainders of x1, y1, z1
	float A,                     // top-left-back grid point value after advection
		B,					 // top-right-back grid point value after advection
		C,                     // bottom-left-back grid point value after advection
		D,					 // bottom-right-back grid point value after advection
		E,                     // top-left-front grid point value after advection
		F,					 // top-right-front grid point value after advection
		G,                     // bottom-left-front grid point value after advection
		H;					 // bottom-right-front grid point value after advection
	float A_Total, B_Total, C_Total, D_Total,
		E_Total, F_Total, G_Total, H_Total;  // Total fraction being requested by the 8 grid points after entire grid has been advected

	// Copy source to destination as reverse advection results in adding/subtracing not moving
	*p_out = *p_in;

	// we need to zero out the fractions 
	Array3D<int>   FromSource_xA(m_w, m_h, m_d, -1);  // The new X coordinate after advection stored in x,y,z where x,y,z,z is the original source point
	Array3D<int>   FromSource_yA(m_w, m_h, m_d, -1);  // The new Y coordinate after advection stored in x,y,z where x,y,z is the original source point
	Array3D<int>   FromSource_zA(m_w, m_h, m_d, -1);  // The new Z coordinate after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_A(m_w, m_h, m_d);		  // The value of A after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_B(m_w, m_h, m_d);		  // The value of B after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_C(m_w, m_h, m_d);       // The value of C after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_D(m_w, m_h, m_d);       // The value of D after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_E(m_w, m_h, m_d);		  // The value of E after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_F(m_w, m_h, m_d);		  // The value of F after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_G(m_w, m_h, m_d);       // The value of G after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> FromSource_H(m_w, m_h, m_d);       // The value of H after advection stored in x,y,z where x,y,z is the original source point
	Array3D<float> TotalDestValue(m_w, m_h, m_d);     // The total accumulated value after advection stored in x,y,z where x,y,z is the destination point

	// This can easily be threaded as the input array is independent from the output array
	for (int x = 0; x < m_w; x++)
	{
		for (int y = 0; y < m_h; y++)
		{
			for (int z = 0; z < m_d; z++)
			{
				vx = mp_velocity->SourceX()->element(x,y,z);
				vy = mp_velocity->SourceY()->element(x,y,z);
				vz = mp_velocity->SourceZ()->element(x,y,z);
				if (!EqualToZero(vx) || !EqualToZero(vy) || !EqualToZero(vz))
				{
					// Find the floating point location of the advection
					x1 = x + vx * force;
					y1 = y + vy * force;
					z1 = z + vz * force;

					// Check for and correct boundary collisions
					Collide(x1,y1,z1);

					// Find the nearest top-left integer grid point of the advection 
					x1A = (int)x1;
					y1A = (int)y1;
					z1A = (int)z1;

					// Store the fractional parts
					fx1 = x1-x1A;
					fy1 = y1-y1A;
					fz1 = z1-z1A;

					/*
					A_________B
					|\        |\
					| \E______|_\F
					|  |      |  |
					|  |      |  |
					C--|------D  |
					\ |       \ |
					\|G_______\H


					From Mick West:
					By adding the source value into the destination, we handle the problem of multiple destinations
					but by subtracting it from the source we gloss over the problem of multiple sources.
					Suppose multiple destinations have the same (partial) source cells, then what happens is the first dest that 
					is processed will get all of that source cell (or all of the fraction it needs).  Subsequent dest
					cells will get a reduced fraction.  In extreme cases this will lead to holes forming based on 
					the update order.

					Solution:  Maintain an array for dest cells, and source cells.
					For dest cells, store the eight source cells and the eight fractions
					For source cells, store the number of dest cells that source from here, and the total fraction
					E.G.  Dest cells A, B, C all source from cell D (and explicit others XYZ, which we don't need to store)
					So, dest cells store A->D(0.1)XYZ..., B->D(0.5)XYZ.... C->D(0.7)XYZ...
					Source Cell D is updated with A, B then C
					Update A:   Dests = 1, Tot = 0.1
					Update B:   Dests = 2, Tot = 0.6
					Update C:   Dests = 3, Tot = 1.3

					How much should go to each of A, B and C? They are asking for a total of 1.3, so should they get it all, or 
					should they just get 0.4333 in total?
					Ad Hoc answer:  
					if total <=1 then they get what they ask for
					if total >1 then is is divided between them proportionally.
					If there were two at 1.0, they would get 0.5 each
					If there were two at 0.5, they would get 0.5 each
					If there were two at 0.1, they would get 0.1 each
					If there were one at 0.6 and one at 0.8, they would get 0.6/1.4 and 0.8/1.4  (0.429 and 0.571) each

					So in our example, total is 1.3, 
					A gets 0.1/1.3, B gets 0.6/1.3 C gets 0.7/1.3, all totalling 1.0

					*/
					// Bilinear interpolation
					A = (1.0f-fz1)*(1.0f-fy1)*(1.0f-fx1);
					B = (1.0f-fz1)*(1.0f-fy1)*(fx1);
					C = (1.0f-fz1)*(fy1)     *(1.0f-fx1);
					D = (1.0f-fz1)*(fy1)     *(fx1);
					E = (fz1)     *(1.0f-fy1)*(1.0f-fx1);
					F = (fz1)     *(1.0f-fy1)*(fx1);
					G = (fz1)     *(fy1)     *(1.0f-fx1);
					H = (fz1)     *(fy1)     *(fx1);


					// Store the coordinates of destination point A for this source point (x,y,z)
					FromSource_xA.element(x,y,z) = x1A;  
					FromSource_yA.element(x,y,z) = y1A;
					FromSource_zA.element(x,y,z) = z1A;

					// Store the values of A,B,C,D,E,F,G,H for this source point
					FromSource_A.element(x,y,z) = A;
					FromSource_B.element(x,y,z) = B;
					FromSource_C.element(x,y,z) = C;
					FromSource_D.element(x,y,z) = D;
					FromSource_E.element(x,y,z) = E;
					FromSource_F.element(x,y,z) = F;
					FromSource_G.element(x,y,z) = G;
					FromSource_H.element(x,y,z) = H;

					// Accumullting the total value for the four destinations
					TotalDestValue.element(x1A,y1A,z1A)	      += A;
					TotalDestValue.element(x1A+1,y1A,z1A)	  += B;
					TotalDestValue.element(x1A,y1A+1,z1A)	  += C;
					TotalDestValue.element(x1A+1,y1A+1,z1A)   += D;
					TotalDestValue.element(x1A,y1A,z1A+1)	  += E;
					TotalDestValue.element(x1A+1,y1A,z1A+1)	  += F;
					TotalDestValue.element(x1A,y1A+1,z1A+1)	  += G;
					TotalDestValue.element(x1A+1,y1A+1,z1A+1) += H;
				}
			}
		}
	}

	for (int y = 0; y < m_h; y++)
	{
		for (int x = 0; x < m_w; x++)
		{
			for (int z = 0; z < m_d; z++)
			{
				if (FromSource_xA.element(x,y,z) != -1)
				{
					// Get the coordinates of A
					x1A = FromSource_xA.element(x,y,z);
					y1A = FromSource_yA.element(x,y,z);
					z1A = FromSource_zA.element(x,y,z);

					// Get the four fractional amounts we earlier interpolated
					A = FromSource_A.element(x,y,z);  
					B = FromSource_B.element(x,y,z);  
					C = FromSource_C.element(x,y,z);
					D = FromSource_D.element(x,y,z);
					E = FromSource_E.element(x,y,z);  
					F = FromSource_F.element(x,y,z);  
					G = FromSource_G.element(x,y,z);
					H = FromSource_H.element(x,y,z);

					// Get the TOTAL fraction requested from each source cell
					A_Total = TotalDestValue.element(x1A,y1A,z1A);
					B_Total = TotalDestValue.element(x1A+1,y1A,z1A);
					C_Total = TotalDestValue.element(x1A,y1A+1,z1A);
					D_Total = TotalDestValue.element(x1A+1,y1A+1,z1A);
					E_Total = TotalDestValue.element(x1A,y1A,z1A+1);
					F_Total = TotalDestValue.element(x1A+1,y1A,z1A+1);
					G_Total = TotalDestValue.element(x1A,y1A+1,z1A+1);
					H_Total = TotalDestValue.element(x1A+1,y1A+1,z1A+1);

					// If less then 1.0 in total then no scaling is neccessary
					if (A_Total<1.0f) A_Total = 1.0f;
					if (B_Total<1.0f) B_Total = 1.0f;
					if (C_Total<1.0f) C_Total = 1.0f;
					if (D_Total<1.0f) D_Total = 1.0f;
					if (E_Total<1.0f) E_Total = 1.0f;
					if (F_Total<1.0f) F_Total = 1.0f;
					if (G_Total<1.0f) G_Total = 1.0f;
					if (H_Total<1.0f) H_Total = 1.0f;

					// Scale the amount we are transferring
					A /= A_Total;
					B /= B_Total;
					C /= C_Total;
					D /= D_Total;
					E /= E_Total;
					F /= F_Total;
					G /= G_Total;
					H /= H_Total;

					// Give the fraction of the original source, do not alter the original
					// So we are taking fractions from p_in, but not altering those values as they are used again by later cells
					// if the field were mass conserving, then we could simply move the value but if we try that we lose mass
					p_out->element(x,y,z) += A * p_in->element(x1A,y1A,z1A) + 
						B * p_in->element(x1A+1,y1A,z1A) + 
						C * p_in->element(x1A,y1A+1,z1A) + 
						D * p_in->element(x1A+1,y1A+1,z1A) +
						E * p_in->element(x1A,y1A,z1A+1) + 
						F * p_in->element(x1A+1,y1A,z1A+1) + 
						G * p_in->element(x1A,y1A+1,z1A+1) + 
						H * p_in->element(x1A+1,y1A+1,z1A+1);

					// Subtract the values added to the destination from the source for mass conservation
					p_out->element(x1A,y1A,z1A)       -= A * p_in->element(x1A,y1A,z1A);
					p_out->element(x1A+1,y1A,z1A)     -= B * p_in->element(x1A+1,y1A,z1A);
					p_out->element(x1A,y1A+1,z1A)     -= C * p_in->element(x1A,y1A+1,z1A);
					p_out->element(x1A+1,y1A+1,z1A)   -= D * p_in->element(x1A+1,y1A+1,z1A);
					p_out->element(x1A,y1A,z1A+1)     -= E * p_in->element(x1A,y1A,z1A+1);
					p_out->element(x1A+1,y1A,z1A+1)   -= F * p_in->element(x1A+1,y1A,z1A+1);
					p_out->element(x1A,y1A+1,z1A+1)   -= G * p_in->element(x1A,y1A+1,z1A+1);
					p_out->element(x1A+1,y1A+1,z1A+1) -= H * p_in->element(x1A+1,y1A+1,z1A+1);
				}
			}
		}
	}
}


void FluidSimulation3D::Diffusion(Fluid3D *p_in, Fluid3D *p_out, const float scale)
{

	float force = m_dt * scale ;

	// Iterate through cells along the top and bottom surfaces (not including corners).  5 neighbors total. 
	for (int x = 1; x < m_w-1; x++)
	{
		for (int z = 1; z < m_d-1; z++)
		{
			p_out->element(x,0,z) = p_in->element(x,0,z) + force * 
				(p_in->element(x-1,0,z) + 
				p_in->element(x+1,0,z) + 
				p_in->element(x,0,z-1) + 
				p_in->element(x,0,z+1) + 
				p_in->element(x,1,z) - 5.0f * p_in->element(x,0,z));
			p_out->element(x,m_h-1,z) = p_in->element(x,m_h-1,z) + force * 
				(p_in->element(x-1,m_h-1,z) + 
				p_in->element(x+1,m_h-1,z) + 
				p_in->element(x,m_h-1,z-1) + 
				p_in->element(x,m_h-1,z+1) + 
				p_in->element(x,m_h-2,z) - 5.0f * p_in->element(x,m_h-1,z));
		}
	}
	// Iterate through cells along the left and right surfaces (not including corners).  5 neighbors total. 
	for (int y = 1; y < m_h-1; y++)
	{
		for (int z = 1; z < m_d-1; z++)
		{
			p_out->element(0,y,z) = p_in->element(0,y,z) + force * 
				(p_in->element(0,y-1,z) + 
				p_in->element(0,y+1,z) + 
				p_in->element(0,y,z-1) + 
				p_in->element(0,y,z+1) + 
				p_in->element(1,y,z) - 5.0f * p_in->element(0,y,z));
			p_out->element(m_w-1,y,z) = p_in->element(m_w-1,y,z) + force * 
				(p_in->element(m_w-1,y-1,z) + 
				p_in->element(m_w-1,y+1,z) + 
				p_in->element(m_w-1,y,z-1) + 
				p_in->element(m_w-1,y,z+1) + 
				p_in->element(m_w-2,y,z) - 5.0f * p_in->element(m_w-1,y,z));
		}
	}

	// Iterate through cells along the front and back surfaces (not including corners).  5 neighbors total. 
	for (int x = 1; x < m_w-1; x++)
	{
		for (int y = 1; y < m_h-1; y++)
		{
			p_out->element(x,y,0) = p_in->element(x,y,0) + force * 
				(p_in->element(x,y-1,0) + 
				p_in->element(x,y+1,0) + 
				p_in->element(x-1,y,0) + 
				p_in->element(x+1,y,0) + 
				p_in->element(x,y,1) - 5.0f * p_in->element(x,y,0));
			p_out->element(x,y,m_d-1) = p_in->element(x,y,m_d-1) + force * 
				(p_in->element(x,y-1,m_d-1) + 
				p_in->element(x,y+1,m_d-1) + 
				p_in->element(x-1,y,m_d-1) + 
				p_in->element(x+1,y,m_d-1) + 
				p_in->element(x,y,m_d-2) - 5.0f * p_in->element(x,y,m_d-1));
		}
	}

	// Iterate through cells along the x axis.  4 neighbors total. 
	for (int x = 1; x < m_w-1; x++)
	{
		p_out->element(x,0,0) = p_in->element(x,0,0) + force * 
			(p_in->element(x-1,0,0) + 
			p_in->element(x+1,0,0) + 
			p_in->element(x,0,1) + 
			p_in->element(x,1,0) - 4.0f * p_in->element(x,0,0));
		p_out->element(x,m_h-1,0) = p_in->element(x,m_h-1,0) + force * 
			(p_in->element(x-1,m_h-1,0) + 
			p_in->element(x+1,m_h-1,0) + 
			p_in->element(x,m_h-2,0) + 
			p_in->element(x,m_h-1,1) - 4.0f * p_in->element(x,m_h-1,0));
		p_out->element(x,0,m_d-1) = p_in->element(x,0,m_d-1) + force * 
			(p_in->element(x-1,0,m_d-1) + 
			p_in->element(x+1,0,m_d-1) + 
			p_in->element(x,0,m_d-2) + 
			p_in->element(x,1,m_d-1) - 4.0f * p_in->element(x,0,m_d-1));
		p_out->element(x,m_h-1,m_d-1) = p_in->element(x,m_h-1,m_d-1) + force * 
			(p_in->element(x-1,m_h-1,m_d-1) + 
			p_in->element(x+1,m_h-1,m_d-1) + 
			p_in->element(x,m_h-2,m_d-1) + 
			p_in->element(x,m_h-1,m_d-2) - 4.0f * p_in->element(x,m_h-1,m_d-1));
	}

	// Iterate through cells along the y axis.  4 neighbors total. 
	for (int y = 1; y < m_h-1; y++)
	{
		p_out->element(0,y,0) = p_in->element(0,y,0) + force * 
			(p_in->element(0,y-1,0) + 
			p_in->element(0,y+1,0) + 
			p_in->element(0,y,1) + 
			p_in->element(1,y,0) - 4.0f * p_in->element(0,y,0));
		p_out->element(m_w-1,y,0) = p_in->element(m_w-1,y,0) + force * 
			(p_in->element(m_w-1,y-1,0) + 
			p_in->element(m_w-1,y+1,0) + 
			p_in->element(m_w-1,y,1) + 
			p_in->element(m_w-2,y,0) - 4.0f * p_in->element(m_w-1,y,0));
		p_out->element(0,y,m_d-1) = p_in->element(0,y,m_d-1) + force * 
			(p_in->element(0,y-1,m_d-1) + 
			p_in->element(0,y+1,m_d-1) + 
			p_in->element(0,y,m_d-2) + 
			p_in->element(1,y,m_d-1) - 4.0f * p_in->element(0,y,m_d-1));
		p_out->element(m_w-1,y,m_d-1) = p_in->element(m_w-1,y,m_d-1) + force * 
			(p_in->element(m_w-1,y-1,m_d-1) + 
			p_in->element(m_w-1,y+1,m_d-1) + 
			p_in->element(m_w-1,y,m_d-2) + 
			p_in->element(m_w-2,y,m_d-1) - 4.0f * p_in->element(m_w-1,y,m_d-1));
	}

	// Iterate through cells along the z axis.  4 neighbors total. 
	for (int z = 1; z < m_d-1; z++)
	{
		p_out->element(0,0,z) = p_in->element(0,0,z) + force * 
			(p_in->element(0,0,z-1) + 
			p_in->element(0,0,z+1) + 
			p_in->element(1,0,z) + 
			p_in->element(0,1,z) - 4.0f * p_in->element(0,0,z));
		p_out->element(m_w-1,0,z) = p_in->element(m_w-1,0,z) + force * 
			(p_in->element(m_w-1,0,z-1) + 
			p_in->element(m_w-1,0,z+1) + 
			p_in->element(m_w-2,0,z) + 
			p_in->element(m_w-1,1,z) - 4.0f * p_in->element(m_w-1,0,z));
		p_out->element(0,m_h-1,z) = p_in->element(0,m_h-1,z) + force * 
			(p_in->element(0,m_h-1,z-1) + 
			p_in->element(0,m_h-1,z+1) + 
			p_in->element(1,m_h-1,z) + 
			p_in->element(0,m_h-2,z) - 4.0f * p_in->element(0,m_h-1,z));
		p_out->element(m_w-1,m_h-1,z) = p_in->element(m_w-1,m_h-1,z) + force * 
			(p_in->element(m_w-1,m_h-1,z-1) + 
			p_in->element(m_w-1,m_h-1,z+1) + 
			p_in->element(m_w-2,m_h-1,z) + 
			p_in->element(m_w-1,m_h-2,z) - 4.0f * p_in->element(m_w-1,m_h-1,z));
	}

	// Diffuse the last 8 corner cells.  3 neighbors total. 
	p_out->element(0,0,0) = p_in->element(0,0,0) + force * 
		(p_in->element(1,0,0) + 
		p_in->element(0,1,0) + 
		p_in->element(0,0,1) - 3.0f * p_in->element(0,0,0));
	p_out->element(m_w-1,0,0) = p_in->element(m_w-1,0,0) + force * 
		(p_in->element(m_w-2,0,0) + 
		p_in->element(m_w-1,1,0) + 
		p_in->element(m_w-1,0,1) - 3.0f * p_in->element(m_w-1,0,0));
	p_out->element(0,m_h-1,0) = p_in->element(0,m_h-1,0) + force * 
		(p_in->element(1,m_h-1,0) + 
		p_in->element(0,m_h-2,0) + 
		p_in->element(0,m_h-1,1) - 3.0f * p_in->element(0,m_h-1,0));
	p_out->element(m_w-1,m_h-1,0) = p_in->element(m_w-1,m_h-1,0) + force * 
		(p_in->element(m_w-2,m_h-1,0) +
		p_in->element(m_w-1,m_h-2,0) +
		p_in->element(m_w-1,m_h-1,1) - 3.0f * p_in->element(m_w-1,m_h-1,0));
	p_out->element(0,0,m_d-1) = p_in->element(0,0,m_d-1) + force * 
		(p_in->element(1,0,m_d-1) + 
		p_in->element(0,1,m_d-1) + 
		p_in->element(0,0,m_d-2) - 3.0f * p_in->element(0,0,m_d-1));
	p_out->element(m_w-1,0,m_d-1) = p_in->element(m_w-1,0,m_d-1) + force * 
		(p_in->element(m_w-2,0,m_d-1) + 
		p_in->element(m_w-1,1,m_d-1) + 
		p_in->element(m_w-1,0,m_d-2) - 3.0f * p_in->element(m_w-1,0,m_d-1));
	p_out->element(0,m_h-1,m_d-1) = p_in->element(0,m_h-1,m_d-1) + force * 
		(p_in->element(1,m_h-1,m_d-1) + 
		p_in->element(0,m_h-2,m_d-1) + 
		p_in->element(0,m_h-1,m_d-2) - 3.0f * p_in->element(0,m_h-1,m_d-1));
	p_out->element(m_w-1,m_h-1,m_d-1) = p_in->element(m_w-1,m_h-1,m_d-1) + force * 
		(p_in->element(m_w-2,m_h-1,m_d-1) + 
		p_in->element(m_w-1,m_h-2,m_d-1) + 
		p_in->element(m_w-1,m_h-1,m_d-2) - 3.0f * p_in->element(m_w-1,m_h-1,m_d-1));

	// Iterate through all the remaining cells that are not touching a boundary.  6 neighbors total.
	for (int x = 1; x < m_w-1; x++)
	{
		for (int y = 1; y < m_h-1; y++)
		{
			for (int z = 1; z < m_d-1; z++)
			{
				p_out->element(x,y,z) = p_in->element(x,y,z) + force * 
					(p_in->element(x,y,z+1) + 
					p_in->element(x,y,z-1) + 
					p_in->element(x,y+1,z) + 
					p_in->element(x,y-1,z) + 
					p_in->element(x+1,y,z) + 
					p_in->element(x-1,y,z) - 6.0f * p_in->element(x,y,z));
			}
		}
	}
}
#endif


// Signed advection is mass conserving, but allows signed quantities 
// so could be used for velocity, since it's faster.
void FluidSimulation3D::ReverseSignedAdvection(VelPkg3D *v, const float advectScale)
{
	float scale = v->Properties()->advection * advectScale;
	// negate advection scale, since it's reverse advection
	float force = - m_dt * scale ;
	float vx, vy, vz;            // velocity values of the current x,y,z locations
	float x1, y1, z1;			 // x, y, z locations after advection
	int   x1A, y1A, z1A;		 // x, y, z locations of top-left-back grid point (A) after advection
	float fx1, fy1, fz1;		 // fractional remainders of x1, y1, z1
	float A_X, A_Y, A_Z,         // top-left-back grid point value after advection
		B_X, B_Y, B_Z,	     // top-right-back grid point value after advection
		C_X, C_Y, C_Z,         // bottom-left-back grid point value after advection
		D_X, D_Y, D_Z, 		 // bottom-right-back grid point value after advection
		E_X, E_Y, E_Z,         // top-left-front grid point value after advection
		F_X, F_Y, F_Z,	     // top-right-front grid point value after advection
		G_X, G_Y, G_Z,         // bottom-left-front grid point value after advection
		H_X, H_Y, H_Z;		 // bottom-right-front grid point value after advection
	bool bCollide;

	// First copy the scalar values over, since we are adding/subtracting in values, not moving things
	Fluid3D velOutX = *v->DestinationX();
	Fluid3D velOutY = *v->DestinationY();
	Fluid3D velOutZ = *v->DestinationZ();

	for (int x = 0; x < m_w; x++)
	{
		for (int y = 0; y < m_h; y++)
		{
			for (int z = 0; z < m_d; z++)
			{
				vx = mp_velocity->SourceX()->element(x,y,z);
				vy = mp_velocity->SourceY()->element(x,y,z);
				vz = mp_velocity->SourceZ()->element(x,y,z);
				if (!EqualToZero(vx) || !EqualToZero(vy) || !EqualToZero(vz))
				{
					// Find the floating point location of the advection
					x1 = x + vx * force;
					y1 = y + vy * force;
					z1 = z + vz * force;

					bCollide = Collide(x1,y1,z1);

					// Find the nearest top-left integer grid point of the advection 
					x1A = (int)x1;
					y1A = (int)y1;
					z1A = (int)z1;

					// Store the fractional parts
					fx1 = x1-x1A;
					fy1 = y1-y1A;
					fz1 = z1-z1A;

					// Get amounts from (in) source cells for X velocity
					A_X = (1.0f-fx1)*(1.0f-fy1)*(1.0f-fz1) * v->DestinationX()->element(x1A, y1A, z1A);   	
					B_X = (fx1)     *(1.0f-fy1)*(1.0f-fz1) * v->DestinationX()->element(x1A+1, y1A, z1A);   	
					C_X = (1.0f-fx1)*(fy1)     *(1.0f-fz1) * v->DestinationX()->element(x1A, y1A+1, z1A);   	
					D_X = (fx1)     *(fy1)     *(1.0f-fz1) * v->DestinationX()->element(x1A+1, y1A+1, z1A);	
					E_X = (1.0f-fx1)*(1.0f-fy1)*(fz1)      * v->DestinationX()->element(x1A, y1A, z1A+1);    
					F_X = (fx1)     *(1.0f-fy1)*(fz1)      * v->DestinationX()->element(x1A+1, y1A, z1A+1);  
					G_X = (1.0f-fx1)*(fy1)     *(fz1)      * v->DestinationX()->element(x1A, y1A+1, z1A+1);  
					H_X = (fx1)     *(fy1)     *(fz1)      * v->DestinationX()->element(x1A+1, y1A+1, z1A+1);

					// Get amounts from (in) source cells for Y velocity
					A_Y = (1.0f-fx1)*(1.0f-fy1)*(1.0f-fz1) * v->DestinationY()->element(x1A, y1A, z1A);   	
					B_Y = (fx1)     *(1.0f-fy1)*(1.0f-fz1) * v->DestinationY()->element(x1A+1, y1A, z1A);   	
					C_Y = (1.0f-fx1)*(fy1)     *(1.0f-fz1) * v->DestinationY()->element(x1A, y1A+1, z1A);   	
					D_Y = (fx1)     *(fy1)     *(1.0f-fz1) * v->DestinationY()->element(x1A+1, y1A+1, z1A);	
					E_Y = (1.0f-fx1)*(1.0f-fy1)*(fz1)      * v->DestinationY()->element(x1A, y1A, z1A+1);    
					F_Y = (fx1)     *(1.0f-fy1)*(fz1)      * v->DestinationY()->element(x1A+1, y1A, z1A+1);  
					G_Y = (1.0f-fx1)*(fy1)     *(fz1)      * v->DestinationY()->element(x1A, y1A+1, z1A+1);  
					H_Y = (fx1)     *(fy1)     *(fz1)      * v->DestinationY()->element(x1A+1, y1A+1, z1A+1);

					// Get amounts from (in) source cells for Z velocity
					A_Z = (1.0f-fx1)*(1.0f-fy1)*(1.0f-fz1) * v->DestinationZ()->element(x1A, y1A, z1A);   	
					B_Z = (fx1)     *(1.0f-fy1)*(1.0f-fz1) * v->DestinationZ()->element(x1A+1, y1A, z1A);   	
					C_Z = (1.0f-fx1)*(fy1)     *(1.0f-fz1) * v->DestinationZ()->element(x1A, y1A+1, z1A);   	
					D_Z = (fx1)     *(fy1)     *(1.0f-fz1) * v->DestinationZ()->element(x1A+1, y1A+1, z1A);	
					E_Z = (1.0f-fx1)*(1.0f-fy1)*(fz1)      * v->DestinationZ()->element(x1A, y1A, z1A+1);    
					F_Z = (fx1)     *(1.0f-fy1)*(fz1)      * v->DestinationZ()->element(x1A+1, y1A, z1A+1);  
					G_Z = (1.0f-fx1)*(fy1)     *(fz1)      * v->DestinationZ()->element(x1A, y1A+1, z1A+1);  
					H_Z = (fx1)     *(fy1)     *(fz1)      * v->DestinationZ()->element(x1A+1, y1A+1, z1A+1);

					// X Velocity
					// add to (out) source cell
					if (!bCollide) {
						velOutX.element(x,y,z) += A_X + B_X + C_X + D_X + E_X + F_X + G_X + H_X;
					}
					// and subtract from (out) dest cells
					velOutX.element(x1A, y1A, z1A)       -= A_X;
					velOutX.element(x1A+1, y1A, z1A)     -= B_X;
					velOutX.element(x1A, y1A+1, z1A)     -= C_X;
					velOutX.element(x1A+1, y1A+1, z1A)   -= D_X;
					velOutX.element(x1A, y1A, z1A+1)     -= E_X;
					velOutX.element(x1A+1, y1A, z1A+1)   -= F_X;
					velOutX.element(x1A, y1A+1, z1A+1)   -= G_X;
					velOutX.element(x1A+1, y1A+1, z1A+1) -= H_X;

					// Y Velocity
					// add to (out) source cell
					if (!bCollide) {
						velOutY.element(x,y,z) += A_Y + B_Y + C_Y + D_Y + E_Y + F_Y + G_Y + H_Y;
					}
					// and subtract from (out) dest cells
					velOutY.element(x1A, y1A, z1A)       -= A_Y;
					velOutY.element(x1A+1, y1A, z1A)     -= B_Y;
					velOutY.element(x1A, y1A+1, z1A)     -= C_Y;
					velOutY.element(x1A+1, y1A+1, z1A)   -= D_Y;
					velOutY.element(x1A, y1A, z1A+1)     -= E_Y;
					velOutY.element(x1A+1, y1A, z1A+1)   -= F_Y;
					velOutY.element(x1A, y1A+1, z1A+1)   -= G_Y;
					velOutY.element(x1A+1, y1A+1, z1A+1) -= H_Y;

					// Z Velocity
					// add to (out) source cell
					if (!bCollide) {
						velOutZ.element(x,y,z) += A_Z + B_Z + C_Z + D_Z + E_Z + F_Z + G_Z + H_Z;
					}
					// and subtract from (out) dest cells
					velOutZ.element(x1A, y1A, z1A)       -= A_Z;
					velOutZ.element(x1A+1, y1A, z1A)     -= B_Z;
					velOutZ.element(x1A, y1A+1, z1A)     -= C_Z;
					velOutZ.element(x1A+1, y1A+1, z1A)   -= D_Z;
					velOutZ.element(x1A, y1A, z1A+1)     -= E_Z;
					velOutZ.element(x1A+1, y1A, z1A+1)   -= F_Z;
					velOutZ.element(x1A, y1A+1, z1A+1)   -= G_Z;
					velOutZ.element(x1A+1, y1A+1, z1A+1) -= H_Z;
				}
			}
		}
	}

	*v->SourceX() = velOutX;
	*v->SourceY() = velOutY;
	*v->SourceZ() = velOutZ;
}


// Checks if destination point during advection is out of bounds and pulls point in if needed
bool FluidSimulation3D::Collide(float &x1, float &y1, float &z1)
{
	return globalCollide(x1, y1, z1, m_w, m_h, m_d, m_bBoundaryCondition);
}


// Apply acceleration due to pressure
void FluidSimulation3D::PressureAcceleration(const float scale)
{
	float force = m_dt * scale ; 

	*mp_velocity->DestinationX() = *mp_velocity->SourceX();
	*mp_velocity->DestinationY() = *mp_velocity->SourceY();
	*mp_velocity->DestinationZ() = *mp_velocity->SourceZ(); 

	for (int x = 0; x < m_w-1; x++)
	{
		for (int y = 0; y < m_h-1; y++)
		{
			for (int z = 0; z < m_d-1; z++)
			{
				// Pressure differential between points to get an accelleration force.
				float force_x =  mp_pressure->Source()->element(x,y,z)   - mp_pressure->Source()->element(x+1,y,z);  
				float force_y =  mp_pressure->Source()->element(x,y,z)   - mp_pressure->Source()->element(x,y+1,z);  
				float force_z =  mp_pressure->Source()->element(x,y,z)   - mp_pressure->Source()->element(x,y,z+1);  

				// Use the acceleration force to move the velocity field in the appropriate direction. 
				// Ex. If an area of high pressure exists the acceleration force will turn the velocity field
				// away from this area
				mp_velocity->DestinationX()->element(x,y,z)     +=  force * force_x;
				mp_velocity->DestinationX()->element(x+1,y,z)   +=  force * force_x;

				mp_velocity->DestinationY()->element(x,y,z)     +=  force * force_y;
				mp_velocity->DestinationY()->element(x,y+1,z)	+=  force * force_y;

				mp_velocity->DestinationZ()->element(x,y,z)     +=  force * force_z;
				mp_velocity->DestinationZ()->element(x,y,z+1)	+=  force * force_z;
			}
		}
	}

	mp_velocity->SwapLocationsX();
	mp_velocity->SwapLocationsY();
	mp_velocity->SwapLocationsZ();
}


// Apply a natural deceleration to forces applied to the grids
void FluidSimulation3D::ExponentialDecay(Fluid3D *p_in_and_out, const float decay)
{
	for (int x = 0; x < m_w; x++)
	{
		for (int y = 0; y < m_h; y++)
		{
			for (int z = 0; z < m_d; z++)
			{
				p_in_and_out->element(x,y,z) = p_in_and_out->element(x,y,z) * pow(1-decay, m_dt);
			}
		}
	}
}


// Apply vorticities to the simulation
void FluidSimulation3D::VorticityConfinement(const float scale)
{
	float lr_curl;   // curl in the left-right direction
	float ud_curl;   // curl in the up-down direction
	float bf_curl;   // curl in the back-front direction
	float length;    
	float magnitude;

	mp_velocity->DestinationX()->Set(0.0f);
	mp_velocity->DestinationY()->Set(0.0f);
	mp_velocity->DestinationZ()->Set(0.0f);

	for (int i = 1; i < m_w-1; i++)
	{
		for (int j = 1; j < m_h-1; j++)
		{
			for (int k = 1; k < m_d-1; k++)
			{
				m_curl->element(i,j,k) = fabs(Curl(i, j, k));
			}
		}
	}

	for (int x = 2; x < m_w-1; x++)
	{
		for (int y = 2; y < m_h-1; y++)
		{
			for (int z = 2; z < m_d-1; z++)
			{
				// Get curl gradient across cells
				lr_curl = (m_curl->element(x+1,y,z) - m_curl->element(x-1,y,z)) * 0.5f;
				ud_curl = (m_curl->element(x,y+1,z) - m_curl->element(x,y-1,z)) * 0.5f;
				bf_curl = (m_curl->element(x,y,z+1) - m_curl->element(x,y,z-1)) * 0.5f;

				// Normalize the derivitive curl vector
				length = (float) sqrtf(lr_curl * lr_curl + ud_curl * ud_curl + bf_curl * bf_curl) + 0.000001f;
				lr_curl /= length;
				ud_curl /= length;
				bf_curl /= length;

				magnitude = Curl(x, y, z);

				mp_velocity->DestinationX()->element(x,y,z) = -ud_curl *  magnitude;   
				mp_velocity->DestinationY()->element(x,y,z) =  lr_curl *  magnitude;
				mp_velocity->DestinationZ()->element(x,y,z) =  bf_curl *  magnitude;
			}
		}
	}

	*mp_velocity->SourceX() += *mp_velocity->DestinationX() * scale;
	*mp_velocity->SourceY() += *mp_velocity->DestinationY() * scale;
	*mp_velocity->SourceZ() += *mp_velocity->DestinationZ() * scale;
}



// Calculate the curl at position (x,y,z) in the fluid grid. Physically this represents the vortex strength at the
// cell. Computed as follows: w = (del x U) where U is the velocity vector at (i, j).
float FluidSimulation3D::Curl(const int x, const int y, const int z)
{
	// difference in XV of cells above and below
	// positive number is a counter-clockwise rotation
	float x_curl = (mp_velocity->SourceX()->element(x, y + 1, z) - mp_velocity->SourceX()->element(x, y - 1, z)) * 0.5f;

	// difference in YV of cells left and right
	float y_curl = (mp_velocity->SourceY()->element(x + 1, y, z) - mp_velocity->SourceY()->element(x - 1, y, z)) * 0.5f;

	// difference in ZV of cells front and back
	float z_curl = (mp_velocity->SourceZ()->element(x, y, z + 1) - mp_velocity->SourceY()->element(x, y, z - 1)) * 0.5f;

	return x_curl - y_curl - z_curl;
}


// Invert velocities that are facing outwards at boundaries
void FluidSimulation3D::InvertVelocityEdges()
{
	for (int y = 0; y<m_h; y++)
	{
		for (int z = 0; z<m_d; z++)
		{
			if (mp_velocity->SourceX()->element(0,y,z) < 0.0f)
			{
				mp_velocity->SourceX()->element(0,y,z) = -mp_velocity->SourceX()->element(0,y,z);
			}
			if (mp_velocity->SourceX()->element(m_w-1,y,z) > 0.0f)
			{
				mp_velocity->SourceX()->element(m_w-1,y,z) = -mp_velocity->SourceX()->element(m_w-1,y,z);
			}
		}
	}

	for (int x = 0; x<m_w;x++)
	{
		for (int z = 0; z<m_d; z++)
		{
			if (mp_velocity->SourceY()->element(x,0,z) < 0.0f)
			{
				mp_velocity->SourceY()->element(x,0,z) = -mp_velocity->SourceY()->element(x,0,z);
			}
			if (mp_velocity->SourceY()->element(x,m_h-1,z) > 0.0f)
			{
				mp_velocity->SourceY()->element(x,m_h-1,z) = -mp_velocity->SourceY()->element(x,m_h-1,z);
			}
		}
	}

	for (int x = 0; x<m_w;x++)
	{
		for (int y = 0; y<m_h; y++)
		{
			if (mp_velocity->SourceZ()->element(x,y,0) < 0.0f)
			{
				mp_velocity->SourceZ()->element(x,y,0) = -mp_velocity->SourceZ()->element(x,y,0);
			}
			if (mp_velocity->SourceZ()->element(x,y,m_d-1) > 0.0f)
			{
				mp_velocity->SourceZ()->element(x,y,m_d-1) = -mp_velocity->SourceZ()->element(x,y,m_d-1);
			}
		}
	}
}


// float zero approximation
bool FluidSimulation3D::EqualToZero(float in)
{
	if(in < ZERO_MAX && in > ZERO_MIN)
	{
		return true;
	}
	else
	{
		return false;
	}
}


// Reset the simulation's grids to defaults, does not affect individual parameters
void FluidSimulation3D::Reset()
{
	mp_pressure->Reset(1.0f);
	mp_velocity->Reset(0.0f);
	mp_ink->Reset(0.0f);
	mp_heat->Reset(0.0f);
}

// Checks if destination point during advection is out of bounds and pulls the point in if
// reflection on the boundary is being used.
bool globalCollide(float &x1, float &y1, float &z1, int m_w, int m_h, int m_d, bool bBoundaries)
{
	float right_bound = m_w-1.0001f;
	float bot_bound = m_h-1.0001f;
	float front_bound = m_d-1.0001f;
	bool bCollide = false;

	while(x1<0 || x1>right_bound)
	{
		if(x1<0)
		{
			x1 = -x1;
		}
		else if(x1>right_bound)
		{
			x1 = right_bound - (x1 - right_bound);
		}
		bCollide = true;
	}

	while(y1<0 || y1>bot_bound)
	{
		if(y1<0) 
		{
			y1 = -y1;
		}
		else if(y1>bot_bound)
		{
			y1 = bot_bound - (y1 - bot_bound);
		}
		bCollide = true;
	}
	while(z1<0 || z1>front_bound)
	{
		if(z1<0) 
		{
			z1 = -z1;
		}
		else if(z1>front_bound)
		{
			z1 = front_bound - (z1 - front_bound);
		}
		bCollide = true;
	}

	if (bBoundaries) {
		bCollide = false;
	}
	return bCollide;
}

// Accessor methods
int FluidSimulation3D::DiffusionIterations() { return m_diffusionIter; }
void FluidSimulation3D::DiffusionIterations(int value) { m_diffusionIter = value; }
float FluidSimulation3D::Vorticity() { return m_vorticity; }
void FluidSimulation3D::Vorticity(float value) { m_vorticity = value; }
float FluidSimulation3D::PressureAccel() { return m_pressureAccel; }
void FluidSimulation3D::PressureAccel(float value) { m_pressureAccel = value; }
float FluidSimulation3D::dt() { return m_dt; }
void FluidSimulation3D::dt(float value) { m_dt = value; }
FluidPkg3D* FluidSimulation3D::Pressure() { return mp_pressure; }
VelPkg3D* FluidSimulation3D::Velocity(){ return mp_velocity; };
FluidPkg3D* FluidSimulation3D::Ink() { return mp_ink; };
FluidPkg3D* FluidSimulation3D::Heat() { return mp_heat; };
int FluidSimulation3D::Height() { return m_h; }
int FluidSimulation3D::Width() { return m_w; }
int FluidSimulation3D::Depth() { return m_d; }