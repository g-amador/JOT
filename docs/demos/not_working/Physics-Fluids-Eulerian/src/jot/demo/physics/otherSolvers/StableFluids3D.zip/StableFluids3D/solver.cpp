#ifndef _CPP_SOLVER_
#define _CPP_SOLVER_

//project includes
#include "stdhd.hpp"
#include "grid.hpp"
#include "solid_object.hpp"
#include "solver.hpp"
#include "linear_solvers.hpp"

/*
-----------------
functions source
-----------------
*/

void CSOLVER::add_source(CGRID *g,float *x,float *s,float dt)
{
	long i,size=(g->T_cells);
	FOR_ALL_CELLS2
	x[i]+=dt*s[i];
	END_FOR_ALL_CELLS
}

void CSOLVER::diffuse(CGRID *g,CSOLID_OBJECT *s_obj,float *x,float *x0,float dt,long iters,long b)
{
	float a;

	//TO DO: replace sending 'a' and '1+6*a',with sending nothing,and deal with the multiphases in the solvers
	if (b==0)
		a=dt*(g->diff[1])*(g->NX)*(g->NY)*(g->NZ);
	else 
		a=dt*(g->visc[1])*(g->NX)*(g->NY)*(g->NZ);

	linear_solver(g,s_obj,x,x0,a,1+6*a,iters,b,_DIFFUSION_SOLVER);
}

void CSOLVER::advect(CGRID *g,CSOLID_OBJECT *s_obj,float *d,float *d0,float *vx,float *vy,float *vz,float dt,long b)
{
	long i,j,k,i0,j0,k0,i1,j1,k1;
	float xf,yf,zf,s0,t0,u0,s1,t1,u1,dtx,dty,dtz;

	dtx=dt*((g->NX)-2);
	dty=dt*((g->NY)-2);
	dtz=dt*((g->NZ)-2);

	if(b==0) {
		g->B_cells=0;
		g->W_cells=0;
	}

	FOR_EACH_CELL2
	xf=(float) i-(dtx*vx[_IX(i,j,k)]); 
	yf=(float) j-(dty*vy[_IX(i,j,k)]);
	zf=(float) k-(dtz*vz[_IX(i,j,k)]);

	if(xf<0.5f) xf=0.5f; 
	if(xf>(((g->NX)-2)+0.5f)) xf=((g->NX)-2)+0.5f; 
	i0=(int) xf; i1=i0+1;

	if(yf<0.5f) yf=0.5f; 
	if(yf>(((g->NY)-2)+0.5f)) yf=((g->NY)-2)+0.5f; 
	j0=(int) yf; j1=j0+1;

	if(zf<0.5f) zf=0.5f; 
	if(zf>(((g->NZ)-2)+0.5f)) zf=((g->NZ)-2)+0.5f; 
	k0=(int) zf; k1=k0+1;

	s1=xf-i0; s0=1-s1; 
	t1=yf-j0; t0=1-t1;
	u1=zf-k0; u0=1-u1; 

	d[_IX(i,j,k)]=s0*(t0*(u0*d0[_IX(i0,j0,k0)]+u1*d0[_IX(i0,j0,k1)])+
		(t1*(u0*d0[_IX(i0,j1,k0)]+u1*d0[_IX(i0,j1,k1)])))
		+s1*(t0*(u0*d0[_IX(i1,j0,k0)]+u1*d0[_IX(i1,j0,k1)])+
		(t1*(u0*d0[_IX(i1,j1,k0)]+u1*d0[_IX(i1,j1,k1)])));

	//Tracking fluids surface part 1: mark the cells that are either air or water
	if(b==0){
		if((((g->w_a_s_bds[_IX(i,j,k)])&_MB)!=_MB)&&(((g->w_a_s_bds[_IX(i,j,k)])&_SB)!=_SB)){ //if not a boundary cell
			if(d[_IX(i,j,k)]>0.2){ //if a cells density is higher than 0.2
				(g->w_a_s_bds[_IX(i,j,k)])=_LL1; //cell is marked as water
				g->W_cells++; //increment one to the total of water cells (surface or not) count
			} else (g->w_a_s_bds[_IX(i,j,k)])=_A; //otherwise cell is marked as air
			//else (g->w_a_s_bds[_IX(i,j,k)])&=0x13ffffff; //otherwise cell is marked as air
			//}
		} else { //increment one to the total of bounding cells count
			g->B_cells++;
		}
	}
	END_FOR_EACH_CELL

	//TO DO: determine 26 neighbours configuration and if this cell is surface or not 
	//Tracking fluids surface part 2: mark the cells that are water surface

	#ifdef _SURFACE_TRACKING_ON
	g->S_cells=0;

	FOR_EACH_CELL2 
	if(b==0){
		if(((g->w_a_s_bds[_IX(i,j,k)])&_LL1)==_LL1){
			if((((g->w_a_s_bds[_IX(i-1,j,k)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i+1,j,k)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i,j-1,k)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i,j+1,k)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i,j,k-1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i,j,k+1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i-1,j-1,k)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i-1,j+1,k)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i-1,j,k-1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i-1,j,k+1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i+1,j-1,k)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i+1,j+1,k)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i+1,j,k-1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i+1,j,k+1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i,j-1,k-1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i,j+1,k-1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i,j-1,k+1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i,j+1,k+1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i-1,j-1,k-1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i-1,j+1,k-1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i-1,j-1,k+1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i-1,j+1,k+1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i+1,j-1,k-1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i+1,j+1,k-1)])&~_A)==_A)||
				(((g->w_a_s_bds[_IX(i+1,j-1,k+1)])&~_A)==_A)||(((g->w_a_s_bds[_IX(i+1,j+1,k+1)])&~_A)==_A)){ 
				//if at least one water cell's neighbour is air 	
				g->w_a_s_bds[_IX(i,j,k)]=_SL1; //cell is water surface cell	
				g->S_cells++; //increment one to the total of surface cells count
			}
		}
	}
	END_FOR_EACH_CELL
	#endif //_SURFACE_TRACKING_ON

	CLINEAR_SOLVERS::_set_bnd(g,s_obj,b,d);
}

void CSOLVER::project(CGRID *g,CSOLID_OBJECT *s_obj,float *vx,float *vy,float *vz,float *p,float *div)
{
	long i,j,k;

	FOR_EACH_CELL2
	div[_IX(i,j,k)]=-0.5f*(
		(vx[_IX(i+1,j,k)]-vx[_IX(i-1,j,k)])/((g->NX)-2)+
		(vy[_IX(i,j+1,k)]-vy[_IX(i,j-1,k)])/((g->NY)-2)+
		(vz[_IX(i,j,k+1)]-vz[_IX(i,j,k-1)])/((g->NZ)-2));
	p[_IX(i,j,k)]=0;
	END_FOR_EACH_CELL

	CLINEAR_SOLVERS::_set_bnd(g,s_obj,0,div); 
	CLINEAR_SOLVERS::_set_bnd(g,s_obj,0,p);

	linear_solver(g,s_obj,p,div,1,6,_VELOCITY_PROJECTION_ITERS,0,_PROJECTION_SOLVER);

	FOR_EACH_CELL2
	vx[_IX(i,j,k)]-=0.5f*((g->NX)-2)*(p[_IX(i+1,j,k)]-p[_IX(i-1,j,k)]);
	vy[_IX(i,j,k)]-=0.5f*((g->NY)-2)*(p[_IX(i,j+1,k)]-p[_IX(i,j-1,k)]);
	vz[_IX(i,j,k)]-=0.5f*((g->NZ)-2)*(p[_IX(i,j,k+1)]-p[_IX(i,j,k-1)]);
	END_FOR_EACH_CELL

	CLINEAR_SOLVERS::_set_bnd(g,s_obj,1,vx); 
	CLINEAR_SOLVERS::_set_bnd(g,s_obj,2,vy);
	CLINEAR_SOLVERS::_set_bnd(g,s_obj,3,vy);
}

void CSOLVER::linear_solver(CGRID *g,CSOLID_OBJECT *s_obj,float *x,float *x0,float a,float iter,long iters,long b,long solver)
{
	switch(solver){
		case 0: 
			#ifdef _JCB
			CLINEAR_SOLVERS::_jcb(g,s_obj,x,x0,a,iter,iters,b);
			#endif			
			break;
		case 1: 
			#ifdef _GS
			CLINEAR_SOLVERS::_gs(g,s_obj,x,x0,a,iter,iters,b);
			#endif		
			break;
		case 2: 
			#ifdef _CG
			CLINEAR_SOLVERS::_cg(g,s_obj,x,x0,a,iter,iters,b);
			#endif			
			break;
	}
}

void CSOLVER::_fluid_simulator(CGRID *g,CSOLID_OBJECT *s_obj,float dt) 
{
	//printf("add external accelerations\n");
	add_source(g,(g->vx),(g->vx0),dt);
	add_source(g,(g->vy),(g->vy0),dt);
	add_source(g,(g->vz),(g->vz0),dt);
	
	//printf("diffuse velocities\n");
	diffuse(g,s_obj,(g->vx0),(g->vx),dt,_VELOCITY_DIFFUSION_ITERS,1);
	diffuse(g,s_obj,(g->vy0),(g->vy),dt,_VELOCITY_DIFFUSION_ITERS,2);
	diffuse(g,s_obj,(g->vz0),(g->vz),dt,_VELOCITY_DIFFUSION_ITERS,3);
	
	//printf("project1\n");
	project(g,s_obj,(g->vx0),(g->vy0),(g->vz0),(g->vx),(g->vy));
	
	//printf("advect velocities\n");
	advect(g,s_obj,(g->vx),(g->vx0),(g->vx0),(g->vy0),(g->vz0),dt,1);
	advect(g,s_obj,(g->vy),(g->vy0),(g->vx0),(g->vy0),(g->vz0),dt,2);
	advect(g,s_obj,(g->vz),(g->vz0),(g->vx0),(g->vy0),(g->vz0),dt,3);
	
	//printf("project2\n");
	project(g,s_obj,(g->vx),(g->vy),(g->vz),(g->vx0),(g->vy0));

	//printf("add source\n");
	add_source(g,(g->d),(g->d0),dt);

	//printf("diffuse density\n");
	diffuse(g,s_obj,(g->d0),(g->d),dt,_DENSITY_DIFFUSION_ITERS,0);
	
	//printf("advect density\n");
	advect(g,s_obj,(g->d),(g->d0),(g->vx),(g->vy),(g->vz),dt,0);
}

#endif //_CPP_SOLVER_
