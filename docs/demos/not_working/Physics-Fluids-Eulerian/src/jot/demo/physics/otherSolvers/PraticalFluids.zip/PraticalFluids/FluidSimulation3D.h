//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// Portions of the terrain tiling and grass code, DXUT, and basic shaders were
// adapted from the PIX Workshop GDC 2007 sample source code.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Portions of the fluid simulation are based on the original work 
// "Practical Fluid Mechanics" by Mick West used with permission.
//	http://www.gamasutra.com/view/feature/1549/practical_fluid_dynamics_part_1.php
//	http://www.gamasutra.com/view/feature/1615/practical_fluid_dynamics_part_2.php
//	http://cowboyprogramming.com/2008/04/01/practical-fluid-mechanics/
//
// Portions of the volumetric shader used with permission.
// "Real-Time Volume Graphics", Engel et. al. Ch 7, Fig. 7.1
// Copyright 2006 A K Peters Ltd.
//	http://www.real-time-volume-graphics.org/
//-------------------------------------------------------------------------------------

#pragma once

#include "BaseInclude.h"

#include "blocked_range.h"
#include "parallel_for.h"

#include "TaskManager.h"
#include "FluidPkg3D.h"
#include "VelPkg3D.h"
#include <math.h>


#if RUN_MULTITHREADED
// Forward declarations of TBB context classes
// See the () operator for the simulation code executed by TBB
class ApplyDiffusion;
class ApplyReverseAdvection;
class ApplyForwardAdvection;
#endif

bool globalCollide(float &x1, float &y1, float &z1, int m_w, int m_h, int m_d, bool bBoundaries);


// Defines how fluid objects can interact with each other in order to create a fluid simulation
class FluidSimulation3D
{
public:

	// Constructor - Set size of array and timestep
	FluidSimulation3D(int xSize, int ySize, int zSize, float dt);

	// Destructor
	~FluidSimulation3D();

	// Updates all fluid objects across a single timestep
	void Update(unsigned int numThreads);

	// Applies diffusion across the simulation grids
	void UpdateDiffusion();

	// Applies forces across the simulation grids
	void UpdateForces();

	// Advects across the simulation grids, resulting in net ink and velocity states
	void UpdateAdvection();

	// Resets the fluid simulation to the default state
	void Reset();

	// Fluid object accessors
	VelPkg3D* Velocity();
	FluidPkg3D* Pressure();
	FluidPkg3D* Ink();
	FluidPkg3D* Heat();

	// Fluid property accessors
	int DiffusionIterations();
	void DiffusionIterations(int value);
	float Vorticity();
	void Vorticity(float value);
	float PressureAccel();
	void PressureAccel(float value);
	float dt();
	void dt(float value);
	int Height();
	int Width();
	int Depth();
	bool m_bBoundaryCondition;

protected:
	// Fluid objects
	Fluid3D *m_curl;
	VelPkg3D *mp_velocity;
	FluidPkg3D *mp_pressure;  // equivalent to density
	FluidPkg3D *mp_ink;       // ink is one fluid suspended in another, like smoke in air
	FluidPkg3D *mp_heat;
	unsigned int m_numThreads;

#if RUN_MULTITHREADED
	// TBB context classes
	ApplyDiffusion* m_diffusionContext;
	ApplyReverseAdvection* m_rAdvectionContext;
	ApplyForwardAdvection* m_fAdvectionContext;
#endif

	// Fluid properties
	int m_diffusionIter;    // diffusion cycles per call to Update()
	float m_vorticity;      // level of vorticity confinement to apply
	float m_pressureAccel;  // Pressure accelleration.  Values >0.5 are more realistic, values too large lead to chaotic waves
	float m_dt;             // time step
	int m_w;                // width of simulation
	int m_h;				// height of simulation
	int m_d;				// depth of the simulation

private:
	// Apply heat as a diffusion step in 3D
	void Heat(float scale);

	// Forward advection moves the value at each grid point forward along the velocity field 
	// and dissipates it between the four neare st ending points, values are scaled to be > 0
	// Drawback: Does not handle the dissipation of single cells of pressure (or lines of cells)
	void ForwardAdvection(Fluid3D *p_in, Fluid3D *p_out, float scale);

	// Reverse advection moves the value at each grid point backward along the velocity field 
	// and dissipates it between the four nearest ending points, values are scaled to be > 0
	// Drawback: Does not handle self-advection of velocity without diffusion
	void ReverseAdvection(Fluid3D *p_in, Fluid3D *p_out, float scale);

	// Reverse Signed Advection is a simpler implementation of ReverseAdvection that does not scale 
	// the values to be > 0.  Used for self-advecting velocity as velocity can be < 0.
	void ReverseSignedAdvection(VelPkg3D *v, const float scale);

	// Smooth out the velocity and pressure fields by applying a diffusion filter
	void Diffusion(Fluid3D *p_in, Fluid3D *p_out, const float scale);

	// Checks if destination point during advection is out of bounds and pulls point in if needed
	bool Collide(float &x, float &y, float &z);

	// Alters velocity to move areas of high pressure to low pressure to emulate incompressibility and mass conservation.
	// Allows mass to circulate and not compress into a single cell
	void PressureAcceleration(const float force);

	// Exponentially Decays value towards zero to emulate natural friction on the forces
	void ExponentialDecay(Fluid3D *p_in_and_out, const float decay);

	// Cosmetic patch that accellerates the velocity field in a direction tangential to the curve defined by the surrounding points
	// in ordert to produce vorticities in the fluid 
	void VorticityConfinement(const float scale); 

	// Returns the vortex strength (curl) at the specified cell. 
	float Curl(const int x, const int y, const int z);

	// Invert velocities that are facing outwards at boundaries
	void InvertVelocityEdges();

	// Checks if floats are aprox equal to zero. 
	bool EqualToZero(float in);
};


#if RUN_MULTITHREADED
// Applies diffusion over a TBB supplied range on the simulation's data sets.
// This class essentially supplies a lambda function as proposed for the new C++ standard
// as an object function prototype.
class ApplyDiffusion
{
	Fluid3D* m_fluidIn;
	Fluid3D* m_fluidOut;
	float m_dt;
	float m_force;
	int m_w;
	int m_h;
	int m_d;

public:
	// TBB automatically supplies the range to be processed based on the data set size and the number
	// of threads as calculated by the uGrainSize parameter specified in the call to parallel_for.
	void operator()(const tbb::blocked_range<unsigned int> &range) const
	{
		int x, y, z;
		for(unsigned int gridPos = range.begin(); gridPos != range.end(); gridPos++)
		{
			x = gridPos % m_w;
			y = (gridPos / m_w) % m_h;
			z = gridPos / (m_w * m_h);

			// Update all the remaining cells that are not touching a boundary.  6 neighbors total.
			if((x >= 1) && (x < m_w-1) && (y >= 1) && (y < m_h-1) && (z >= 1) && (z < m_d-1))
			{
				m_fluidOut->element(x,y,z) = m_fluidIn->element(x,y,z) + m_force * 
					(m_fluidIn->element(x,y,z+1) + m_fluidIn->element(x,y,z-1) + m_fluidIn->element(x,y+1,z) + 
					m_fluidIn->element(x,y-1,z) + m_fluidIn->element(x+1,y,z) + 
					m_fluidIn->element(x-1,y,z) - 6.0f * m_fluidIn->element(x,y,z));
			}
		}
	}

	// Initializer
	void Set(Fluid3D *p_in, 
		Fluid3D *p_out,
		float dt,
		float force,
		int w,
		int h,
		int d)
	{
		m_fluidIn = p_in;
		m_fluidOut = p_out;
		m_dt = dt;
		m_force = force;
		m_w = w;
		m_h = h;
		m_d = d;
	}

	ApplyDiffusion()
	{
	}
};

// Applies the reverse advection step over a TBB supplied range on the simulation's data sets.
// This class essentially supplies a lambda function as proposed for the new C++ standard
// as an object function prototype.
class ApplyReverseAdvection
{
	Fluid3D *m_source;
	Fluid3D *m_destination;
	VelPkg3D *m_velocity;
	Array3D<int> *m_FromSource_xA;
	Array3D<int> *m_FromSource_yA;
	Array3D<int> *m_FromSource_zA;
	Array3D<float> *m_FromSource_A;
	Array3D<float> *m_FromSource_B;
	Array3D<float> *m_FromSource_C;
	Array3D<float> *m_FromSource_D;
	Array3D<float> *m_FromSource_E;
	Array3D<float> *m_FromSource_F;
	Array3D<float> *m_FromSource_G;
	Array3D<float> *m_FromSource_H;
	Array3D<float> *m_TotalDestValue;
	float m_force;
	int m_w;
	int m_h;
	int m_d;
	bool m_partOne;
	bool m_bBoundaryCondition;
public:
	// float zero approximation
	bool IsZero(float in) const
	{
		return (in < ZERO_MAX && in > ZERO_MIN);
	}

	// Edge case detection, forcing a reflection when attempting to advect beyond the dimension of the volume
	bool Collide(float &x1, float &y1, float &z1) const
	{
		return globalCollide(x1, y1, z1, m_w, m_h, m_d, m_bBoundaryCondition);
	}

	// Reverse advection part 1.
	// runs in two phases resulting from two distince loops in the original code over the data sets.
	// In keeping with the original code structure, we spearated these out in a similar fashion to two parallel functions
	// executed synchronously.
	void ApplyReverseAdvectionPart1(
		VelPkg3D *velocity,
		Array3D<int> *FromSource_xA,
		Array3D<int> *FromSource_yA,
		Array3D<int> *FromSource_zA,
		Array3D<float> *FromSource_A,
		Array3D<float> *FromSource_B,
		Array3D<float> *FromSource_C,
		Array3D<float> *FromSource_D,
		Array3D<float> *FromSource_E,
		Array3D<float> *FromSource_F,
		Array3D<float> *FromSource_G,
		Array3D<float> *FromSource_H,
		Array3D<float> *TotalDestValue,
		float force,
		unsigned int uBegin,
		unsigned int uEnd) const
	{
		int x1A, y1A, z1A;
		float vx, vy, vz;
		float x1, y1, z1;
		float fx1, fy1, fz1;
		float A, B,	C, D, E, F, G, H;
		bool bCollide;

		unsigned int indexX;
		unsigned int indexY;
		unsigned int indexZ;

		for(unsigned int gridPos = uBegin; gridPos < uEnd; gridPos++)
		{
			indexX = gridPos % m_w;
			indexY = (gridPos / m_w) % m_h;
			indexZ = gridPos / (m_w * m_h);

			vx = velocity->SourceX()->element(indexX, indexY, indexZ);
			vy = velocity->SourceY()->element(indexX, indexY, indexZ);
			vz = velocity->SourceZ()->element(indexX, indexY, indexZ);
			if (!IsZero(vx) || !IsZero(vy) || !IsZero(vz))
			{
				// Find the floating point location of the advection
				x1 = indexX + vx * force;
				y1 = indexY + vy * force;
				z1 = indexZ + vz * force;

				// Check for and correct boundary collisions
				bCollide = Collide(x1,y1,z1);

				// Find the nearest top-left integer grid point of the advection 
				x1A = (int)x1;
				y1A = (int)y1;
				z1A = (int)z1;

				// Store the fractional parts
				fx1 = x1-x1A;
				fy1 = y1-y1A;
				fz1 = z1-z1A;

				// Bilinear interpolation
				A = (1.0f-fz1)*(1.0f-fy1)*(1.0f-fx1);
				B = (1.0f-fz1)*(1.0f-fy1)*(fx1);
				C = (1.0f-fz1)*(fy1)     *(1.0f-fx1);
				D = (1.0f-fz1)*(fy1)     *(fx1);
				E = (fz1)     *(1.0f-fy1)*(1.0f-fx1);
				F = (fz1)     *(1.0f-fy1)*(fx1);
				G = (fz1)     *(fy1)     *(1.0f-fx1);
				H = (fz1)     *(fy1)     *(fx1);

				// Store the coordinates of destination point A for this source point (x,y,z)
				FromSource_xA->element(indexX, indexY, indexZ) = x1A;  
				FromSource_yA->element(indexX, indexY, indexZ) = y1A;
				FromSource_zA->element(indexX, indexY, indexZ) = z1A;

				if (bCollide) {
					FromSource_xA->element(indexX, indexY, indexZ) = -1;
				}

				// Store the values of A,B,C,D,E,F,G,H for this source point
				FromSource_A->element(indexX, indexY, indexZ) = A;
				FromSource_B->element(indexX, indexY, indexZ) = B;
				FromSource_C->element(indexX, indexY, indexZ) = C;
				FromSource_D->element(indexX, indexY, indexZ) = D;
				FromSource_E->element(indexX, indexY, indexZ) = E;
				FromSource_F->element(indexX, indexY, indexZ) = F;
				FromSource_G->element(indexX, indexY, indexZ) = G;
				FromSource_H->element(indexX, indexY, indexZ) = H;

				// Accumulating the total value for the four destinations
				TotalDestValue->element(x1A,y1A,z1A)	      += A;
				TotalDestValue->element(x1A+1,y1A,z1A)	  += B;
				TotalDestValue->element(x1A,y1A+1,z1A)	  += C;
				TotalDestValue->element(x1A+1,y1A+1,z1A)   += D;
				TotalDestValue->element(x1A,y1A,z1A+1)	  += E;
				TotalDestValue->element(x1A+1,y1A,z1A+1)	  += F;
				TotalDestValue->element(x1A,y1A+1,z1A+1)	  += G;
				TotalDestValue->element(x1A+1,y1A+1,z1A+1) += H;
			}
		}
	}

	// Reverse advection part 2.
	// runs in two phases resulting from two distince loops in the original code over the data sets.
	// In keeping with the original code structure, we spearated these out in a similar fashion to two parallel functions
	// executed synchronously.
	void ApplyReverseAdvectionPart2(
		Fluid3D *src,
		Fluid3D *dest,
		Array3D<int> *FromSource_xA,
		Array3D<int> *FromSource_yA,
		Array3D<int> *FromSource_zA,
		Array3D<float> *FromSource_A,
		Array3D<float> *FromSource_B,
		Array3D<float> *FromSource_C,
		Array3D<float> *FromSource_D,
		Array3D<float> *FromSource_E,
		Array3D<float> *FromSource_F,
		Array3D<float> *FromSource_G,
		Array3D<float> *FromSource_H,
		Array3D<float> *TotalDestValue,
		unsigned int uBegin,
		unsigned int uEnd) const
	{
		int x1A, y1A, z1A;
		float A, B,	C, D, E, F, G, H;
		float A_Total, B_Total, C_Total, D_Total, E_Total, F_Total, G_Total, H_Total;

		unsigned int indexX;
		unsigned int indexY;
		unsigned int indexZ;

		for(unsigned int gridPos = uBegin; gridPos < uEnd; gridPos++)
		{
			indexX = gridPos % m_w;
			indexY = (gridPos / m_w) % m_h;
			indexZ = gridPos / (m_w * m_h);

			if(FromSource_xA->element(indexX, indexY, indexZ) != -1)
			{
				// Get the coordinates of A
				x1A = FromSource_xA->element(indexX, indexY, indexZ);
				y1A = FromSource_yA->element(indexX, indexY, indexZ);
				z1A = FromSource_zA->element(indexX, indexY, indexZ);

				// Get the four fractional amounts we earlier interpolated
				A = FromSource_A->element(indexX, indexY, indexZ);
				B = FromSource_B->element(indexX, indexY, indexZ);  
				C = FromSource_C->element(indexX, indexY, indexZ);
				D = FromSource_D->element(indexX, indexY, indexZ);
				E = FromSource_E->element(indexX, indexY, indexZ);  
				F = FromSource_F->element(indexX, indexY, indexZ);  
				G = FromSource_G->element(indexX, indexY, indexZ);
				H = FromSource_H->element(indexX, indexY, indexZ);

				// Get the TOTAL fraction requested from each source cell
				A_Total = TotalDestValue->element(x1A,y1A,z1A);
				B_Total = TotalDestValue->element(x1A+1,y1A,z1A);
				C_Total = TotalDestValue->element(x1A,y1A+1,z1A);
				D_Total = TotalDestValue->element(x1A+1,y1A+1,z1A);
				E_Total = TotalDestValue->element(x1A,y1A,z1A+1);
				F_Total = TotalDestValue->element(x1A+1,y1A,z1A+1);
				G_Total = TotalDestValue->element(x1A,y1A+1,z1A+1);
				H_Total = TotalDestValue->element(x1A+1,y1A+1,z1A+1);

				// If less then 1.0 in total then no scaling is neccessary
				if(A_Total<1.0f) A_Total = 1.0f;
				if(B_Total<1.0f) B_Total = 1.0f;
				if(C_Total<1.0f) C_Total = 1.0f;
				if(D_Total<1.0f) D_Total = 1.0f;
				if(E_Total<1.0f) E_Total = 1.0f;
				if(F_Total<1.0f) F_Total = 1.0f;
				if(G_Total<1.0f) G_Total = 1.0f;
				if(H_Total<1.0f) H_Total = 1.0f;

				// Scale the amount we are transferring
				A /= A_Total;
				B /= B_Total;
				C /= C_Total;
				D /= D_Total;
				E /= E_Total;
				F /= F_Total;
				G /= G_Total;
				H /= H_Total;

				// Give the fraction of the original source, do not alter the original
				// So we are taking fractions from src, but not altering those values as they are used again by later cells
				// if the field were mass conserving, then we could simply move the value but if we try that we lose mass
				dest->element(indexX, indexY, indexZ) += A * src->element(x1A,y1A,z1A) + 
					B * src->element(x1A+1,y1A,z1A) + 
					C * src->element(x1A,y1A+1,z1A) + 
					D * src->element(x1A+1,y1A+1,z1A) +
					E * src->element(x1A,y1A,z1A+1) + 
					F * src->element(x1A+1,y1A,z1A+1) + 
					G * src->element(x1A,y1A+1,z1A+1) + 
					H * src->element(x1A+1,y1A+1,z1A+1);

				// Subtract the values added to the destination from the source for mass conservation
				dest->element(x1A,y1A,z1A)       -= A * src->element(x1A,y1A,z1A);
				dest->element(x1A+1,y1A,z1A)     -= B * src->element(x1A+1,y1A,z1A);
				dest->element(x1A,y1A+1,z1A)     -= C * src->element(x1A,y1A+1,z1A);
				dest->element(x1A+1,y1A+1,z1A)   -= D * src->element(x1A+1,y1A+1,z1A);
				dest->element(x1A,y1A,z1A+1)     -= E * src->element(x1A,y1A,z1A+1);
				dest->element(x1A+1,y1A,z1A+1)   -= F * src->element(x1A+1,y1A,z1A+1);
				dest->element(x1A,y1A+1,z1A+1)   -= G * src->element(x1A,y1A+1,z1A+1);
				dest->element(x1A+1,y1A+1,z1A+1) -= H * src->element(x1A+1,y1A+1,z1A+1);
			}
		}
	}

	// TBB automatically supplies the range to be processed based on the data set size and the number
	// of threads as calculated by the uGrainSize parameter specified in the call to parallel_for.
	void operator()(const tbb::blocked_range<unsigned int> &range) const
	{
		if(m_partOne)
		{
			ApplyReverseAdvectionPart1(m_velocity, m_FromSource_xA, m_FromSource_yA, m_FromSource_zA, 
				m_FromSource_A, m_FromSource_B, m_FromSource_C, m_FromSource_D, m_FromSource_E, m_FromSource_F, m_FromSource_G, 
				m_FromSource_H, m_TotalDestValue, m_force, range.begin(), range.end());
		}
		else
		{
			ApplyReverseAdvectionPart2(m_source, m_destination, m_FromSource_xA, m_FromSource_yA, m_FromSource_zA, m_FromSource_A, 
				m_FromSource_B, m_FromSource_C, m_FromSource_D, m_FromSource_E, m_FromSource_F, m_FromSource_G, m_FromSource_H, 
				m_TotalDestValue, range.begin(), range.end());
		}
	}

	// Initializer
	void Set(Fluid3D *src, Fluid3D *dest, VelPkg3D *vel,
		Array3D<int> *FSxA, Array3D<int> *FSyA, Array3D<int> *FSzA,
		Array3D<float> *FSA, Array3D<float> *FSB, Array3D<float> *FSC,
		Array3D<float> *FSD, Array3D<float> *FSE, Array3D<float> *FSF,
		Array3D<float> *FSG, Array3D<float> *FSH, Array3D<float> *TDV,
		float frc, int w, int h, int d, bool p1, bool bBoundaryCondition)
	{
		m_source = src;
		m_destination = dest;
		m_velocity = vel;
		m_FromSource_xA = FSxA; 
		m_FromSource_yA = FSyA;
		m_FromSource_zA =FSzA;
		m_FromSource_A = FSA;
		m_FromSource_B = FSB;
		m_FromSource_C = FSC;
		m_FromSource_D = FSD;
		m_FromSource_E = FSE;
		m_FromSource_F = FSF;
		m_FromSource_G = FSG;
		m_FromSource_H = FSH;
		m_TotalDestValue = TDV;
		m_force = frc;
		m_w = w;
		m_h = h;
		m_d = d;
		m_partOne = p1;
		m_bBoundaryCondition = bBoundaryCondition;
	}

	ApplyReverseAdvection()
	{
	}
};

// Applies the forward advection step over a TBB supplied range on the simulation's data sets.
// This class essentially supplies a lambda function as proposed for the new C++ standard
// as an object function prototype.
class ApplyForwardAdvection
{
	Fluid3D *m_source;
	Fluid3D *m_destination;
	VelPkg3D *m_velocity;
	float m_force;
	int m_w;
	int m_h;
	int m_d;
	bool m_bBoundaryCondition;

public:
	// float zero approximation
	bool IsZero(float in) const
	{
		return (in < ZERO_MAX && in > ZERO_MIN);
	}

	// Edge case detection, forcing a reflection when attempting to advect beyond the dimension of the volume
	bool Collide(float &x1, float &y1, float &z1) const
	{
		return globalCollide(x1, y1, z1, m_w, m_h, m_d, m_bBoundaryCondition);
	}

	// TBB automatically supplies the range to be processed based on the data set size and the number
	// of threads as calculated by the uGrainSize parameter specified in the call to parallel_for.
	void operator()(const tbb::blocked_range<unsigned int> &range) const
	{
		float vx, vy, vz;   
		float x1, y1, z1;	
		int   x1A, y1A, z1A;
		float fx1, fy1, fz1;
		float source_value;	
		float A, B, C, D, E, F, G, H;				
		unsigned int indexX;
		unsigned int indexY;
		unsigned int indexZ;
		bool bCollide;

		Fluid3D *src = m_source;
		Fluid3D *dest = m_destination;
		VelPkg3D *vel = m_velocity;

		for(unsigned int gridPos = range.begin(); gridPos != range.end(); gridPos++)
		{
			indexX = gridPos % m_w;
			indexY = (gridPos / m_w) % m_h;
			indexZ = gridPos / (m_w * m_h);

			vx = vel->SourceX()->element(indexX, indexY, indexZ);
			vy = vel->SourceY()->element(indexX, indexY, indexZ);
			vz = vel->SourceZ()->element(indexX, indexY, indexZ);
			if (!IsZero(vx) || !IsZero(vy) || !IsZero(vz))
			{
				// Find the floating point location of the forward advection
				x1 = indexX + vx * m_force;
				y1 = indexY + vy * m_force;
				z1 = indexZ + vz * m_force;

				// Check for and correct boundary collisions
				bCollide = Collide(x1,y1,z1);

				// Find the nearest top-left integer grid point of the advection 
				x1A = (int)x1;
				y1A = (int)y1;
				z1A = (int)z1;

				// Store the fractional parts
				fx1 = x1-x1A;
				fy1 = y1-y1A;
				fz1 = z1-z1A;

				// Pull source value from the unmodified src
				source_value = src->element(indexX, indexY, indexZ);

				// Bilinear interpolation
				A = (1.0f-fz1)*(1.0f-fy1)*(1.0f-fx1) * source_value;
				B = (1.0f-fz1)*(1.0f-fy1)*(fx1)      * source_value;
				C = (1.0f-fz1)*(fy1)     *(1.0f-fx1) * source_value;
				D = (1.0f-fz1)*(fy1)     *(fx1)      * source_value;
				E = (fz1)     *(1.0f-fy1)*(1.0f-fx1) * source_value;
				F = (fz1)     *(1.0f-fy1)*(fx1)      * source_value;
				G = (fz1)     *(fy1)     *(1.0f-fx1) * source_value;
				H = (fz1)     *(fy1)     *(fx1)      * source_value;

				// Add A,B,C,D,E,F,G,H to the eight destination cells
				if (!bCollide ) {
					dest->element(x1A, y1A, z1A)     	+= A;
					dest->element(x1A+1, y1A, z1A)   	+= B;
					dest->element(x1A, y1A+1, z1A)   	+= C;
					dest->element(x1A+1, y1A+1, z1A)	+= D;
					dest->element(x1A, y1A, z1A+1)    	+= E;
					dest->element(x1A+1, y1A, z1A+1)  	+= F;
					dest->element(x1A, y1A+1, z1A+1)  	+= G;
					dest->element(x1A+1, y1A+1, z1A+1)	+= H;
				}

				// Subtract A-H from source for mass conservation
				dest->element(indexX, indexY, indexZ) -= (A+B+C+D+E+F+G+H);
			}
		}
	}

	// Initializer
	void Set(Fluid3D *src,
		Fluid3D *dest,
		VelPkg3D *vel,
		float frc,
		int w,
		int h,
		int d,
		bool bBoundaryCondition)
	{
		m_source = src ; 
		m_destination = dest ; 
		m_velocity = vel ; 
		m_force = frc ; 
		m_w = w ; 
		m_h = h ; 
		m_d = d;
		m_bBoundaryCondition = bBoundaryCondition;
	}

	ApplyForwardAdvection()
	{
	}
};
#endif