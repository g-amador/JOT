//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//
//--------------------------------------------------------------------------------------
// Portions of the terrain tiling and grass code, DXUT, and basic shaders were
// adapted from the PIX Workshop GDC 2007 sample source code.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Portions of the fluid simulation are based on the original work 
// "Practical Fluid Mechanics" by Mick West used with permission.
//	http://www.gamasutra.com/view/feature/1549/practical_fluid_dynamics_part_1.php
//	http://www.gamasutra.com/view/feature/1615/practical_fluid_dynamics_part_2.php
//	http://cowboyprogramming.com/2008/04/01/practical-fluid-mechanics/
//
// Portions of the volumetric shader used with permission.
// "Real-Time Volume Graphics", Engel et. al. Ch 7, Fig. 7.1
// Copyright 2006 A K Peters Ltd.
//	http://www.real-time-volume-graphics.org/
//-------------------------------------------------------------------------------------

#include "FluidPkg3D.h"

FluidPkg3D::FluidPkg3D(int x, int y, int z) : m_X(x), m_Y(y), m_Z(z)
{
	mp_prop = new FluidProperties();
	mp_prop->diffusion = 0.0f;
	mp_prop->advection = 0.0f;
	mp_prop->force = 0.0f;
	mp_prop->decay = 0.0f;
	mp_source = new Fluid3D(m_X, m_Y, m_Z);
	mp_dest = new Fluid3D(m_X, m_Y, m_Z);
}


FluidPkg3D::~FluidPkg3D()
{
	SAFE_DELETE(mp_prop);
	SAFE_DELETE(mp_source);
	SAFE_DELETE(mp_dest);
}


FluidPkg3D& FluidPkg3D::operator= (const FluidPkg3D& right)
{
	if (this != &right)
	{
		delete mp_source;
		delete mp_dest;
		delete mp_prop;
		mp_source = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_dest = new Fluid3D(right.m_X, right.m_Y, right.m_Z);
		mp_prop = new FluidProperties();
		mp_prop->diffusion = right.mp_prop->diffusion;
		mp_prop->advection = right.mp_prop->advection;
		mp_prop->force = right.mp_prop->force;
		mp_prop->decay = right.mp_prop->decay;
	}
	return *this;
}

void FluidPkg3D::SwapLocations() 
{
	Fluid3D *temp = mp_source;
	mp_source = mp_dest;
	mp_dest = temp;
}

void FluidPkg3D::Reset(float v)
{
	mp_source->Set(v);
	mp_dest->Set(v);
}

Fluid3D* FluidPkg3D::Source()          { return mp_source; }
Fluid3D* FluidPkg3D::Destination()      { return mp_dest; }
FluidProperties* FluidPkg3D::Properties() { return mp_prop; }

