== WHAT?

Small Java Raytracer based on Andrew Kensler business card raytracer (http://www.cs.utah.edu/~aek/code/card.cpp)

== RESULT

![alt tag](https://github.com/dluchian/Raytracer/blob/master/image.png?raw=true)
