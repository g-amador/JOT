Inhalt der verschiedenen Versionen:
Renderer 1: rendert eine Kugel, keine Beleuchtung, schwarzer Hintergrund
Renderer 2: zusätzlich Wände, Decke und Boden
Renderer 3: zusätzlich Phong-Beleuchtung
Renderer 4: zusätzlich Schatten für die Kugel
Renderer 5: zusätzlich Reflektionen für die Kugel
Renderer 6: zusätzlich Texturen für Decke und Boden
Renderer 7: zusätzlich multithreaded Rendering
Renderer 8: zusätzlich marmorartige, prozedurale Textur für die Kugel
