package test;

import java.awt.image.BufferedImage;
import java.util.PriorityQueue;

public class Renderer {

	public static final double SPHERE_RADIUS = 1.0;
	public static final Vector LIGHT_POS = new Vector(2, 1.5, 0);

	public static final Vector NORMAL_LEFT = new Vector(-1, 0, 0);
	public static final Vector NORMAL_RIGHT = new Vector(1, 0, 0);
	public static final Vector NORMAL_UP = new Vector(0, 1, 0);
	public static final Vector NORMAL_DOWN = new Vector(0, -1, 0);
	public static final Vector NORMAL_FRONT = new Vector(0, 0, -1);
	public static final Vector NORMAL_BACK = new Vector(0, 0, 1);

	public static final Color RED = new Color(1, 0, 0);
	public static final Color BLUE = new Color(0, 0, 0.1);
	public static final Color BROWN = new Color(0.6, 0.3, 0.15);
	public static final Color WHITE = new Color(1, 1, 1);
	public static final Color BLACK = new Color(0, 0, 0);
	public static final Color GRAY = new Color(0.5, 0.5, 0.5);

	static Vector spherePos = new Vector(0, 0, -3);

	public static class Ray {
		Vector pos, dir;
	}

	/*
	 * Determines whether the given ray hits the sphere. If yes, adds the hit
	 * information to the queue.
	 */
	private static void checkForSphereHit(Ray r, PriorityQueue<Hit> hits) {
		Vector d = spherePos.sub(r.pos);

		/*
		 * Wikipedia says: d = (l*c) +- sqrt((l*c)² - c² + r²) where l is the
		 * ray direction (ray.dir), c is the sphere's centre (spherePos) and r
		 * is the radius. This is for a ray originating at (0,0,0), so we
		 * subtract r.pos from spherePos first.
		 */
		double tmp = r.dir.dotProduct(d); // l*c
		double det = tmp * tmp - d.getLengthSquared() + SPHERE_RADIUS
				* SPHERE_RADIUS;

		if (det >= 0) {// sphere hit!
			double sqrtDet = Math.sqrt(det);
			double dist = tmp - sqrtDet;
			if (dist < 0)
				dist = tmp + sqrtDet;
			if (dist < 0)
				return;
			Hit hit = new Hit();
			hit.dist = dist;
			hit.pos = r.pos.add(r.dir.scale(dist));
			hit.normal = hit.pos.sub(spherePos).normalize();
			hit.color = RED;
			hit.shininess = 32;
			hits.offer(hit);
		}
	}

	/*
	 * Checks whether the given ray hits the wall described by the given plane
	 * (through wallNormal and distance of the origin to the wall. Texture and
	 * colour can be set. If the wall is hit, the corresponding hit information
	 * is added to the queue.
	 */
	private static void checkForWallHit(Ray r, Vector wallNormal,
			double planeOriginDist, Color color, PriorityQueue<Hit> hits) {

		/*
		 * the cosine of the angle between the viewing direction and the surface
		 * normal of the wall.
		 */
		double cosVN = r.dir.dotProduct(wallNormal);
		if (cosVN >= 0)
			return;

		// the distance of the ray's origin to the wall
		double projDist = r.pos.dotProduct(wallNormal) + planeOriginDist;
		// the distance from the origin at which the ray hits the wall
		double dist = -projDist / cosVN;
		if (dist < 0)
			return;

		Hit hit = new Hit();
		hit.dist = dist;
		hit.pos = r.pos.add(r.dir.scale(dist));
		hit.normal = wallNormal;
		hit.color = color;
		hits.offer(hit);
	}

	private static Color doLighting(Hit hit, Ray r) {
		// the direction at which the light hits the surface
		Vector lightDir = hit.pos.sub(LIGHT_POS).normalize();

		Color ambientLight = hit.color.scale(0.15);
		double diffuse = 0, specular = 0;

		/*
		 * the cosine of the angle between light direction and surface normal
		 */
		double cosLN = -hit.normal.dotProduct(lightDir);
		/*
		 * we don't want light if the light source lies behind the object,
		 * therefore we cut off engative cosines
		 */
		diffuse = Math.max(0, cosLN);

		// perform specular lighting
		if (hit.shininess != 0 && cosLN > 0) {
			// The direction of the light ray reflected from the surface
			Vector reflectedDir = lightDir.add(hit.normal.scale(-2
					* lightDir.dotProduct(hit.normal)));
			/*
			 * the cosine of the angle between view direction and reflected ray
			 */
			double cosLR = -reflectedDir.dotProduct(r.dir);
			if (cosLR > 0)
				specular = Math.pow(cosLR, hit.shininess) * (hit.shininess + 2)
						/ (2 * Math.PI);
		}

		Color diffuseLight = hit.color.scale(0.7 * diffuse);
		Color specularLight = WHITE.scale(0.15 * specular);
		return ambientLight.add(diffuseLight).add(specularLight);
	}

	/*
	 * Follows the given ray until an object (sphere or wall) is hit, then
	 * performs texturing, lighting and reflection and returns the colour.
	 */
	private static Color traceRay(Ray r, int recursions) {
		PriorityQueue<Hit> hits = new PriorityQueue<Hit>();
		checkForSphereHit(r, hits);
		checkForWallHit(r, NORMAL_LEFT, 4, BLUE, hits);
		checkForWallHit(r, NORMAL_RIGHT, 4, BLUE, hits);
		checkForWallHit(r, NORMAL_UP, 2, BROWN, hits);
		checkForWallHit(r, NORMAL_DOWN, 2, WHITE, hits);
		checkForWallHit(r, NORMAL_FRONT, 3, BLUE, hits);
		checkForWallHit(r, NORMAL_BACK, 5, BLUE, hits);

		if (hits.isEmpty()) {
			return BLACK; // background
		} else {
			// get closest hit
			Hit hit = hits.peek();
			Color c = doLighting(hit, r);
			return c;
		}
	}

	/*
	 * Renders an image of the given dimensions with viewer at the given
	 * position and looking in the given direction. A red, reflecting sphere is
	 * placed at spherePos and walls are around it.
	 */
	public static void render(Vector pos, Vector view, Vector up,
			Vector spherePos, BufferedImage image) {
		final int width = image.getWidth(), height = image.getHeight();
		Renderer.spherePos = spherePos;

		int[] buffer = new int[width * height];
		Ray ray = new Ray();
		ray.pos = pos;
		// calculate right and up direction
		Vector right = view.crossProduct(up).normalize();
		// ensure view/right/up are pairwise orthogonal
		up = right.crossProduct(view);

		// calculate dimensions of view plane
		double viewPlaneHeight = 1.5;
		double viewPlaneWidth = 1.5 * width / height;

		// sample the view plane
		int k = 0; // index of pixel to be sampled
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				// calculate position of current pixel on view plane
				double leftRight = viewPlaneWidth * (x / (double) width - 0.5);
				double upDown = viewPlaneHeight * (0.5 - y / (double) height);

				// set the direction of the view ray
				ray.dir = view.add(right.scale(leftRight))
						.add(up.scale(upDown)).normalize();

				// perform actual ray tracing
				Color c = traceRay(ray, 1);
				buffer[k++] = c.getRGB();
			}
		}

		// save result to the image
		image.setRGB(0, 0, width, height, buffer, 0, width);

	}
}
