package test;

public final class Color {
	
	private final double r, g, b;

	public Color(int rgb) {
		r = ((rgb >> 16) & 0xff) / 255.0;
		g = ((rgb >> 8) & 0xff) / 255.0;
		b = (rgb & 0xff) / 255.0;
	}

	public Color(double r, double g, double b) {
		this.r = r;
		this.g = g;
		this.b = b;
	}

	public final Color add(Color c) {
		return new Color(r + c.r, g + c.g, b + c.b);
	}

	public final Color scale(double d) {
		return new Color(r * d, g * d, b * d);
	}

	private final int compToInt(double c) {
		return (int) Math.round(Math.max(0, Math.min(255, c * 255)));
	}

	public final int getRGB() {
		int r = compToInt(this.r);
		int g = compToInt(this.g);
		int b = compToInt(this.b);
		return (r << 16) | (g << 8) | b;
	}
}
