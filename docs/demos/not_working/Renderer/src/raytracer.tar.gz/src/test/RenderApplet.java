package test;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;

public class RenderApplet extends Applet {

	@Override
	public void init() {
		super.init();
		setLayout(new BorderLayout());
		add(new RenderPanel(true), BorderLayout.CENTER);
	}
	
}
