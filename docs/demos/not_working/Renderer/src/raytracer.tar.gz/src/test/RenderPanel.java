package test;

import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.MouseInfo;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class RenderPanel extends JPanel {

	private Vector pos = new Vector(0.0, 0.0, 2.0);
	private Vector spherePos = new Vector(0.0, 0.0, -3.0);
	private Vector view = new Vector(0.0, 0.0, -1.0);
	private Vector up = new Vector(0.0, 1.0, 0.0);
	private int lastX, lastY;
	private double pitch, yaw;
	private BufferedImage image;

	public RenderPanel() {
		super();
		init();
	}

	public RenderPanel(boolean isDoubleBuffered) {
		super(isDoubleBuffered);
		init();
	}

	public RenderPanel(LayoutManager layout, boolean isDoubleBuffered) {
		super(layout, isDoubleBuffered);
		init();
	}

	public RenderPanel(LayoutManager layout) {
		super(layout);
		init();
	}

	private void init() {
		setFocusable(true);
		requestFocus();
		addKeyListener(new KeyAdapter() {

			@Override
			public void keyTyped(KeyEvent e) {
				Vector right = view.crossProduct(up).normalize();
				char key = Character.toLowerCase(e.getKeyChar());
				if (key == 'w')
					pos = pos.add(view.scale(0.1));
				else if (key == 's')
					pos = pos.add(view.scale(-0.1));
				else if (key == 'd')
					pos = pos.add(right.scale(0.1));
				else if (key == 'a')
					pos = pos.add(right.scale(-0.1));
				else if (key == 'x')
					pos = pos.add(up.scale(0.1));
				else if (key == 'y')
					pos = pos.add(up.scale(-0.1));
				else
					return;
				updatePosition();
				repaint();
			}
		});

		addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				lastX = e.getX();
				lastY = e.getY();
				if (e.getButton() == MouseEvent.BUTTON3){ 
					spherePos = pos.add(view.scale(5.0));
					repaint();
				}
			}

		});

		addMouseMotionListener(new MouseMotionAdapter() {

			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getX(), y = e.getY();
				int dx = x - lastX, dy = y - lastY;
				Vector right = view.crossProduct(up).normalize();

				if ((e.getModifiersEx() & MouseEvent.BUTTON1_DOWN_MASK) != 0) {
					pos = pos.add(right.scale(dx / 100.0));
					pos = pos.add(up.scale(-dy / 100.0));
					updatePosition();
				}
				if ((e.getModifiersEx() & MouseEvent.BUTTON2_DOWN_MASK) != 0 ||
						(e.getModifiersEx() & MouseEvent.BUTTON3_DOWN_MASK) != 0) {
					yaw -= dx / 500.0;
					pitch += dy / 500.0;
					updateRotation();
				}
				if ((e.getModifiersEx() & MouseEvent.BUTTON2_DOWN_MASK) != 0) {
					spherePos = pos.add(view.scale(5.0));
//					spherePos = spherePos.add(right.scale(dx / 100.0));
//					spherePos = spherePos.add(up.scale(-dy / 100.0));
					updatePosition();
				}

				lastX = x;
				lastY = y;
				repaint();
			}

		});

		addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
				pos = pos.add(view.scale(-0.5 * e.getWheelRotation()));
				updatePosition();
				repaint();
			}
		});
	}

	private void updatePosition() {
		double x = Math.max(-3.5, Math.min(3.5, pos.x));
		double y = Math.max(-1.5, Math.min(1.5, pos.y));
		double z = Math.max(-4.5, Math.min(2.5, pos.z));
		pos = new Vector(x, y, z);
		x = Math.max(-3, Math.min(3, spherePos.x));
		y = Math.max(-1, Math.min(1, spherePos.y));
		z = Math.max(-4, Math.min(2, spherePos.z));
		spherePos = new Vector(x, y, z);
	}

	private void updateRotation() {
		pitch = Math.max(-1.5, Math.min(1.5, pitch));
		double x = Math.cos(pitch) * Math.sin(yaw);
		double y = Math.sin(pitch);
		double z = -Math.cos(pitch) * Math.cos(yaw);
		view = (new Vector(x, y, z)).normalize();
		Vector right = view.crossProduct(up).normalize();
	}

	@Override
	protected void paintComponent(Graphics g) {
		int width = getWidth();
		int height = getHeight();
		if (image == null || width != image.getWidth() || height !=
				image.getHeight())
			image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

		Renderer.render(pos, view, up, spherePos, image);
		g.drawImage(image, 0, 0, null);
	}

}
