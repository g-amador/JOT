package test;

public final class Vector {
	final double x, y, z;

	public Vector(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public final Vector add(Vector v) {
		return new Vector(x + v.x, y + v.y, z + v.z);
	}

	public final Vector sub(Vector v) {
		return new Vector(x - v.x, y - v.y, z - v.z);
	}

	public final double getLengthSquared() {
		return x * x + y * y + z * z;
	}

	public final double getLength() {
		return Math.sqrt(x * x + y * y + z * z);
	}

	public final Vector scale(double d) {
		return new Vector(d * x, d * y, d * z);
	}

	public final Vector normalize() {
		return scale(1 / getLength());
	}

	public final double dotProduct(Vector v) {
		return x * v.x + y * v.y + z * v.z;
	}

	public final Vector crossProduct(Vector v) {
		return new Vector(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y
				* v.x);
	}
}