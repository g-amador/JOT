package test;

public class Hit implements Comparable<Hit> {
	Vector pos, normal;
	Color color;
	double dist, reflectivity;
	int shininess;
	Color[][] texture;
	boolean marble;

	public int compareTo(Hit o) {
		return Double.compare(dist, o.dist);
	}
}