function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(710 - 48, 0, 402 + 4 - 255), influenceRepeller);
new Propagator(new Vector3D(710 - 201, 0, 402 + 4 - 246), influenceRepeller);
new Propagator(new Vector3D(710 - 232, 0, 402 + 4 - 170), influenceRepeller);
new Propagator(new Vector3D(710 - 265, 0, 402 + 4 - 106), influenceRepeller);
new Propagator(new Vector3D(710 - 280, 0, 402 + 4 - 106), influenceRepeller);
new Propagator(new Vector3D(710 - 286, 0, 402 + 4 - 106), influenceRepeller);
new Propagator(new Vector3D(710 - 290, 0, 402 + 4 - 106), influenceRepeller);
new Propagator(new Vector3D(710 - 296, 0, 402 + 4 - 106), influenceRepeller);
new Propagator(new Vector3D(710 - 216, 0, 402 + 4 - 87), influenceRepeller);
new Propagator(new Vector3D(710 - 265, 0, 402 + 4 - 87), influenceRepeller);
new Propagator(new Vector3D(710 - 285, 0, 402 + 4 - 88), influenceRepeller);
new Propagator(new Vector3D(710 - 291, 0, 402 + 4 - 88), influenceRepeller);
new Propagator(new Vector3D(710 - 344, 0, 402 + 4 - 88), influenceRepeller);
new Propagator(new Vector3D(710 - 349, 0, 402 + 4 - 88), influenceRepeller);
new Propagator(new Vector3D(710 - 354, 0, 402 + 4 - 88), influenceRepeller);
new Propagator(new Vector3D(710 - 345, 0, 402 + 4 - 112), influenceRepeller);
new Propagator(new Vector3D(710 - 393, 0, 402 + 4 - 88), influenceRepeller);
new Propagator(new Vector3D(710 - 401, 0, 402 + 4 - 159), influenceRepeller);
new Propagator(new Vector3D(710 - 481, 0, 402 + 4 - 87), influenceRepeller);
new Propagator(new Vector3D(710 - 457, 0, 402 + 4 - 152), influenceRepeller);
new Propagator(new Vector3D(710 - 505, 0, 402 + 4 - 80), influenceRepeller);
//Attractors (propagator center is a local minimum)
new Propagator(new Vector3D(710 - 81, 0, 402 + 4 - 255), influenceAttractor);
new Propagator(new Vector3D(710 - 86, 0, 402 + 4 - 255), influenceAttractor);
new Propagator(new Vector3D(710 - 90, 0, 402 + 4 - 252), influenceAttractor);
new Propagator(new Vector3D(710 - 95, 0, 402 + 4 - 252), influenceAttractor);
new Propagator(new Vector3D(710 - 100, 0, 402 + 4 - 252), influenceAttractor);
new Propagator(new Vector3D(710 - 105, 0, 402 + 4 - 252), influenceAttractor);
new Propagator(new Vector3D(710 - 110, 0, 402 + 4 - 252), influenceAttractor);
new Propagator(new Vector3D(710 - 115, 0, 402 + 4 - 252), influenceAttractor);
new Propagator(new Vector3D(710 - 120, 0, 402 + 4 - 248), influenceAttractor);
new Propagator(new Vector3D(710 - 122, 0, 402 + 4 - 244), influenceAttractor);
new Propagator(new Vector3D(710 - 126, 0, 402 + 4 - 242), influenceAttractor);
new Propagator(new Vector3D(710 - 130, 0, 402 + 4 - 240), influenceAttractor);
new Propagator(new Vector3D(710 - 134, 0, 402 + 4 - 240), influenceAttractor);
new Propagator(new Vector3D(710 - 138, 0, 402 + 4 - 240), influenceAttractor);
new Propagator(new Vector3D(710 - 142, 0, 402 + 4 - 240), influenceAttractor);
new Propagator(new Vector3D(710 - 146, 0, 402 + 4 - 240), influenceAttractor);
new Propagator(new Vector3D(710 - 489, 0, 402 + 4 - 45), influenceAttractor);
new Propagator(new Vector3D(710 - 487, 0, 402 + 4 - 40), influenceAttractor);
new Propagator(new Vector3D(710 - 485, 0, 402 + 4 - 35), influenceAttractor);
new Propagator(new Vector3D(710 - 483, 0, 402 + 4 - 30), influenceAttractor);
new Propagator(new Vector3D(710 - 480, 0, 402 + 4 - 25), influenceAttractor);
new Propagator(new Vector3D(710 - 477, 0, 402 + 4 - 20), influenceAttractor);
new Propagator(new Vector3D(710 - 474, 0, 402 + 4 - 15), influenceAttractor);
