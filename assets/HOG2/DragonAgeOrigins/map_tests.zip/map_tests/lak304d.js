function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(193 - 126, 0, 194 + 4 - 180), influenceRepeller);
new Propagator(new Vector3D(193 - 151, 0, 194 + 4 - 163), influenceRepeller);
new Propagator(new Vector3D(193 - 167, 0, 194 + 4 - 152), influenceRepeller);
new Propagator(new Vector3D(193 - 133, 0, 194 + 4 - 143), influenceRepeller);
new Propagator(new Vector3D(193 - 130, 0, 194 + 4 - 140), influenceRepeller);
new Propagator(new Vector3D(193 - 127, 0, 194 + 4 - 137), influenceRepeller);
new Propagator(new Vector3D(193 - 156, 0, 194 + 4 - 118), influenceRepeller);
new Propagator(new Vector3D(193 - 155, 0, 194 + 4 - 78), influenceRepeller);
new Propagator(new Vector3D(193 - 138, 0, 194 + 4 - 76), influenceRepeller);
new Propagator(new Vector3D(193 - 145, 0, 194 + 4 - 75), influenceRepeller);
new Propagator(new Vector3D(193 - 99, 0, 194 + 4 - 91), influenceRepeller);
new Propagator(new Vector3D(193 - 93, 0, 194 + 4 - 93), influenceRepeller);
new Propagator(new Vector3D(193 - 99, 0, 194 + 4 - 127), influenceRepeller);
new Propagator(new Vector3D(193 - 104, 0, 194 + 4 - 124), influenceRepeller);
new Propagator(new Vector3D(193 - 109, 0, 194 + 4 - 121), influenceRepeller);
new Propagator(new Vector3D(193 - 90, 0, 194 + 4 - 128), influenceRepeller);
new Propagator(new Vector3D(193 - 53, 0, 194 + 4 - 118), influenceRepeller);
new Propagator(new Vector3D(193 - 49, 0, 194 + 4 - 118), influenceRepeller);
new Propagator(new Vector3D(193 - 45, 0, 194 + 4 - 118), influenceRepeller);
new Propagator(new Vector3D(193 - 39, 0, 194 + 4 - 85), influenceRepeller);
new Propagator(new Vector3D(193 - 110, 0, 194 + 4 - 57), influenceRepeller);
new Propagator(new Vector3D(193 - 57, 0, 194 + 4 - 18), influenceRepeller);
//Attractors (propagator center is a local minimum)      
new Propagator(new Vector3D(193 - 142, 0, 194 + 4 - 146), influenceAttractor);
new Propagator(new Vector3D(193 - 138, 0, 194 + 4 - 137), influenceAttractor);
new Propagator(new Vector3D(193 - 147, 0, 194 + 4 - 118), influenceAttractor);
new Propagator(new Vector3D(193 - 136, 0, 194 + 4 - 91), influenceAttractor);
new Propagator(new Vector3D(193 - 130, 0, 194 + 4 - 93), influenceAttractor);
new Propagator(new Vector3D(193 - 125, 0, 194 + 4 - 96), influenceAttractor);
new Propagator(new Vector3D(193 - 120, 0, 194 + 4 - 99), influenceAttractor);
new Propagator(new Vector3D(193 - 115, 0, 194 + 4 - 102), influenceAttractor);
new Propagator(new Vector3D(193 - 110, 0, 194 + 4 - 105), influenceAttractor);
new Propagator(new Vector3D(193 - 105, 0, 194 + 4 - 108), influenceAttractor);
new Propagator(new Vector3D(193 - 100, 0, 194 + 4 - 111), influenceAttractor);
new Propagator(new Vector3D(193 - 93, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 88, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 83, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 78, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 73, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 68, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 63, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 58, 0, 194 + 4 - 112), influenceAttractor);
new Propagator(new Vector3D(193 - 53, 0, 194 + 4 - 112), influenceAttractor);
