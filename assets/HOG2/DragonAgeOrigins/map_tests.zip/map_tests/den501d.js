function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(320 - 49, 0, 338 + 4 - 286), influenceRepeller);
new Propagator(new Vector3D(320 - 153, 0, 338 + 4 - 262), influenceRepeller);
new Propagator(new Vector3D(320 - 122, 0, 338 + 4 - 279), influenceRepeller);
new Propagator(new Vector3D(320 - 153, 0, 338 + 4 - 279), influenceRepeller);
new Propagator(new Vector3D(320 - 169, 0, 338 + 4 - 279), influenceRepeller);
new Propagator(new Vector3D(320 - 194, 0, 338 + 4 - 282), influenceRepeller);
new Propagator(new Vector3D(320 - 194, 0, 338 + 4 - 274), influenceRepeller);
new Propagator(new Vector3D(320 - 194, 0, 338 + 4 - 268), influenceRepeller);
new Propagator(new Vector3D(320 - 194, 0, 338 + 4 - 255), influenceRepeller);
new Propagator(new Vector3D(320 - 194, 0, 338 + 4 - 222), influenceRepeller);
new Propagator(new Vector3D(320 - 210, 0, 338 + 4 - 92), influenceRepeller);
new Propagator(new Vector3D(320 - 210, 0, 338 + 4 - 98), influenceRepeller);
new Propagator(new Vector3D(320 - 161, 0, 338 + 4 - 92), influenceRepeller);
new Propagator(new Vector3D(320 - 161, 0, 338 + 4 - 98), influenceRepeller);
new Propagator(new Vector3D(320 - 202, 0, 338 + 4 - 82), influenceRepeller);
new Propagator(new Vector3D(320 - 202, 0, 338 + 4 - 76), influenceRepeller);
//Attractors (propagator center is a local minimum)
new Propagator(new Vector3D(320 - 100, 0, 338 + 4 - 341), influenceAttractor);
new Propagator(new Vector3D(320 - 95, 0, 338 + 4 - 338), influenceAttractor);
new Propagator(new Vector3D(320 - 90, 0, 338 + 4 - 335), influenceAttractor);
new Propagator(new Vector3D(320 - 85, 0, 338 + 4 - 332), influenceAttractor);
new Propagator(new Vector3D(320 - 80, 0, 338 + 4 - 329), influenceAttractor);
new Propagator(new Vector3D(320 - 80, 0, 338 + 4 - 292), influenceAttractor);
new Propagator(new Vector3D(320 - 85, 0, 338 + 4 - 290), influenceAttractor);
new Propagator(new Vector3D(320 - 90, 0, 338 + 4 - 288), influenceAttractor);
new Propagator(new Vector3D(320 - 95, 0, 338 + 4 - 286), influenceAttractor);
new Propagator(new Vector3D(320 - 100, 0, 338 + 4 - 284), influenceAttractor);
new Propagator(new Vector3D(320 - 172, 0, 338 + 4 - 74), influenceAttractor);
new Propagator(new Vector3D(320 - 174, 0, 338 + 4 - 69), influenceAttractor);
new Propagator(new Vector3D(320 - 176, 0, 338 + 4 - 64), influenceAttractor);
new Propagator(new Vector3D(320 - 178, 0, 338 + 4 - 59), influenceAttractor);
new Propagator(new Vector3D(320 - 180, 0, 338 + 4 - 54), influenceAttractor);
new Propagator(new Vector3D(320 - 182, 0, 338 + 4 - 49), influenceAttractor);
