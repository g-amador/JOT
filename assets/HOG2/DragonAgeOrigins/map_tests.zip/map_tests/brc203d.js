function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(274 - 168, 0, 391 + 4 - 320), influenceRepeller);
new Propagator(new Vector3D(274 - 168, 0, 391 + 4 - 326), influenceRepeller);
new Propagator(new Vector3D(274 - 130, 0, 391 + 4 - 320), influenceRepeller);
new Propagator(new Vector3D(274 - 130, 0, 391 + 4 - 326), influenceRepeller);
new Propagator(new Vector3D(274 - 122, 0, 391 + 4 - 330), influenceRepeller);
new Propagator(new Vector3D(274 - 150, 0, 391 + 4 - 272), influenceRepeller);
new Propagator(new Vector3D(274 - 150, 0, 391 + 4 - 278), influenceRepeller);
new Propagator(new Vector3D(274 - 117, 0, 391 + 4 - 269), influenceRepeller);
new Propagator(new Vector3D(274 - 117, 0, 391 + 4 - 273), influenceRepeller);
new Propagator(new Vector3D(274 - 117, 0, 391 + 4 - 277), influenceRepeller);
new Propagator(new Vector3D(274 - 117, 0, 391 + 4 - 281), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 164), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 169), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 174), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 179), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 184), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 189), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 194), influenceRepeller);
new Propagator(new Vector3D(274 - 88, 0, 391 + 4 - 199), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 162), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 167), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 172), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 177), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 182), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 187), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 192), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 197), influenceRepeller);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 202), influenceRepeller);
new Propagator(new Vector3D(274 - 82, 0, 391 + 4 - 70), influenceRepeller);
new Propagator(new Vector3D(274 - 49, 0, 391 + 4 - 51), influenceRepeller);
new Propagator(new Vector3D(274 - 118, 0, 391 + 4 - 53), influenceRepeller);
new Propagator(new Vector3D(274 - 118, 0, 391 + 4 - 49), influenceRepeller);
//Attractors (propagator center is a local minimum)
new Propagator(new Vector3D(274 - 129, 0, 391 + 4 - 232), influenceAttractor);
new Propagator(new Vector3D(274 - 124, 0, 391 + 4 - 227), influenceAttractor);
new Propagator(new Vector3D(274 - 119, 0, 391 + 4 - 225), influenceAttractor);
new Propagator(new Vector3D(274 - 114, 0, 391 + 4 - 223), influenceAttractor);
new Propagator(new Vector3D(274 - 109, 0, 391 + 4 - 221), influenceAttractor);
new Propagator(new Vector3D(274 - 106, 0, 391 + 4 - 216), influenceAttractor);
new Propagator(new Vector3D(274 - 106, 0, 391 + 4 - 209), influenceAttractor);
new Propagator(new Vector3D(274 - 106, 0, 391 + 4 - 204), influenceAttractor);
new Propagator(new Vector3D(274 - 105, 0, 391 + 4 - 96), influenceAttractor);
new Propagator(new Vector3D(274 - 104, 0, 391 + 4 - 91), influenceAttractor);
new Propagator(new Vector3D(274 - 103, 0, 391 + 4 - 86), influenceAttractor);
new Propagator(new Vector3D(274 - 102, 0, 391 + 4 - 81), influenceAttractor);
new Propagator(new Vector3D(274 - 101, 0, 391 + 4 - 76), influenceAttractor);
new Propagator(new Vector3D(274 - 100, 0, 391 + 4 - 71), influenceAttractor);
new Propagator(new Vector3D(274 - 100, 0, 391 + 4 - 66), influenceAttractor);
new Propagator(new Vector3D(274 - 100, 0, 391 + 4 - 61), influenceAttractor);
