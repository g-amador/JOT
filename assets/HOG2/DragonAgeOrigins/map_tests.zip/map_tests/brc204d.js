function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(431 - 233, 0, 429 + 4 - 280), influenceRepeller);
new Propagator(new Vector3D(431 - 202, 0, 429 + 4 - 256), influenceRepeller);
new Propagator(new Vector3D(431 - 218, 0, 429 + 4 - 256), influenceRepeller);
new Propagator(new Vector3D(431 - 137, 0, 429 + 4 - 265), influenceRepeller);
new Propagator(new Vector3D(431 - 138, 0, 429 + 4 - 298), influenceRepeller);
new Propagator(new Vector3D(431 - 90, 0, 429 + 4 - 298), influenceRepeller);
new Propagator(new Vector3D(431 - 64, 0, 429 + 4 - 281), influenceRepeller);
new Propagator(new Vector3D(431 - 28, 0, 429 + 4 - 111), influenceRepeller);
//Attractors (propagator center is a local minimum)
new Propagator(new Vector3D(431 - 94, 0, 429 + 4 - 273), influenceAttractor);
new Propagator(new Vector3D(431 - 93, 0, 429 + 4 - 268), influenceAttractor);
new Propagator(new Vector3D(431 - 92, 0, 429 + 4 - 263), influenceAttractor);
new Propagator(new Vector3D(431 - 91, 0, 429 + 4 - 258), influenceAttractor);
new Propagator(new Vector3D(431 - 90, 0, 429 + 4 - 253), influenceAttractor);
new Propagator(new Vector3D(431 - 89, 0, 429 + 4 - 248), influenceAttractor);
new Propagator(new Vector3D(431 - 88, 0, 429 + 4 - 243), influenceAttractor);
new Propagator(new Vector3D(431 - 87, 0, 429 + 4 - 238), influenceAttractor);
new Propagator(new Vector3D(431 - 82, 0, 429 + 4 - 238), influenceAttractor);
new Propagator(new Vector3D(431 - 77, 0, 429 + 4 - 238), influenceAttractor);
new Propagator(new Vector3D(431 - 72, 0, 429 + 4 - 238), influenceAttractor);
new Propagator(new Vector3D(431 - 67, 0, 429 + 4 - 238), influenceAttractor);
new Propagator(new Vector3D(431 - 62, 0, 429 + 4 - 238), influenceAttractor);
new Propagator(new Vector3D(431 - 57, 0, 429 + 4 - 238), influenceAttractor);
new Propagator(new Vector3D(431 - 52, 0, 429 + 4 - 235), influenceAttractor);
new Propagator(new Vector3D(431 - 47, 0, 429 + 4 - 232), influenceAttractor);
new Propagator(new Vector3D(431 - 42, 0, 429 + 4 - 230), influenceAttractor);
