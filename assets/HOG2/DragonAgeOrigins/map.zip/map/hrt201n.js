function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(294 - 144, 0, 305 + 4 - 237), influenceRepeller);
new Propagator(new Vector3D(294 - 183, 0, 305 + 4 - 213), influenceRepeller);
new Propagator(new Vector3D(294 - 187, 0, 305 + 4 - 213), influenceRepeller);
new Propagator(new Vector3D(294 - 192, 0, 305 + 4 - 203), influenceRepeller);
new Propagator(new Vector3D(294 - 192, 0, 305 + 4 - 181), influenceRepeller);
new Propagator(new Vector3D(294 - 192, 0, 305 + 4 - 177), influenceRepeller);
new Propagator(new Vector3D(294 - 192, 0, 305 + 4 - 173), influenceRepeller);
new Propagator(new Vector3D(294 - 192, 0, 305 + 4 - 169), influenceRepeller);
new Propagator(new Vector3D(294 - 192, 0, 305 + 4 - 165), influenceRepeller);
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 132), influenceRepeller);
new Propagator(new Vector3D(294 - 208, 0, 305 + 4 - 140), influenceRepeller);
new Propagator(new Vector3D(294 - 208, 0, 305 + 4 - 144), influenceRepeller);
new Propagator(new Vector3D(294 - 112, 0, 305 + 4 - 141), influenceRepeller);
new Propagator(new Vector3D(294 - 150, 0, 305 + 4 - 131), influenceRepeller);
new Propagator(new Vector3D(294 - 155, 0, 305 + 4 - 131), influenceRepeller);
new Propagator(new Vector3D(294 - 120, 0, 305 + 4 - 178), influenceRepeller);
new Propagator(new Vector3D(294 - 83, 0, 305 + 4 - 165), influenceRepeller);
new Propagator(new Vector3D(294 - 85, 0, 305 + 4 - 165), influenceRepeller);
new Propagator(new Vector3D(294 - 92, 0, 305 + 4 - 165), influenceRepeller);
new Propagator(new Vector3D(294 - 83, 0, 305 + 4 - 182), influenceRepeller);
new Propagator(new Vector3D(294 - 85, 0, 305 + 4 - 182), influenceRepeller);
new Propagator(new Vector3D(294 - 92, 0, 305 + 4 - 182), influenceRepeller);
new Propagator(new Vector3D(294 - 32, 0, 305 + 4 - 173), influenceRepeller);
new Propagator(new Vector3D(294 - 58, 0, 305 + 4 - 101), influenceRepeller);
new Propagator(new Vector3D(294 - 24, 0, 305 + 4 - 101), influenceRepeller);
new Propagator(new Vector3D(294 - 58, 0, 305 + 4 - 69), influenceRepeller);
new Propagator(new Vector3D(294 - 24, 0, 305 + 4 - 69), influenceRepeller);
//Attractors (propagator center is a local minimum)                 
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 205), influenceAttractor);
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 195), influenceAttractor);
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 185), influenceAttractor);
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 175), influenceAttractor);
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 165), influenceAttractor);
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 155), influenceAttractor);
new Propagator(new Vector3D(294 - 185, 0, 305 + 4 - 145), influenceAttractor);
new Propagator(new Vector3D(294 - 180, 0, 305 + 4 - 140), influenceAttractor);
