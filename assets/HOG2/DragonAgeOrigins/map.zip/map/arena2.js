function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum
new Propagator(new Vector3D(281 - 258, 0, 209 + 4 - 102), influenceRepeller);
new Propagator(new Vector3D(281 - 194, 0, 209 + 4 - 134), influenceRepeller);
new Propagator(new Vector3D(281 - 178, 0, 209 + 4 - 89), influenceRepeller);
new Propagator(new Vector3D(281 - 178, 0, 209 + 4 - 94), influenceRepeller);
new Propagator(new Vector3D(281 - 178, 0, 209 + 4 - 99), influenceRepeller);
new Propagator(new Vector3D(281 - 178, 0, 209 + 4 - 121), influenceRepeller);
new Propagator(new Vector3D(281 - 178, 0, 209 + 4 - 126), influenceRepeller);
new Propagator(new Vector3D(281 - 178, 0, 209 + 4 - 131), influenceRepeller);
new Propagator(new Vector3D(281 - 122, 0, 209 + 4 - 46), influenceRepeller);
new Propagator(new Vector3D(281 - 122, 0, 209 + 4 - 62), influenceRepeller);
//Attractors (propagator center is a local minimum)
new Propagator(new Vector3D(281 - 190, 0, 209 + 4 - 84), influenceAttractor);
new Propagator(new Vector3D(281 - 185, 0, 209 + 4 - 79), influenceAttractor);
new Propagator(new Vector3D(281 - 180, 0, 209 + 4 - 74), influenceAttractor);
new Propagator(new Vector3D(281 - 175, 0, 209 + 4 - 69), influenceAttractor);
new Propagator(new Vector3D(281 - 170, 0, 209 + 4 - 66), influenceAttractor);
new Propagator(new Vector3D(281 - 165, 0, 209 + 4 - 66), influenceAttractor);
new Propagator(new Vector3D(281 - 160, 0, 209 + 4 - 61), influenceAttractor);
