function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)                  
new Propagator(new Vector3D(530 - 480, 0, 481 + 4 - 444), influenceRepeller);
new Propagator(new Vector3D(530 - 480, 0, 481 + 4 - 448), influenceRepeller);
new Propagator(new Vector3D(530 - 459, 0, 481 + 4 - 372), influenceRepeller);
new Propagator(new Vector3D(530 - 460, 0, 481 + 4 - 237), influenceRepeller);
new Propagator(new Vector3D(530 - 486, 0, 481 + 4 - 188), influenceRepeller);
new Propagator(new Vector3D(530 - 450, 0, 481 + 4 - 189), influenceRepeller);
new Propagator(new Vector3D(530 - 450, 0, 481 + 4 - 94), influenceRepeller);
new Propagator(new Vector3D(530 - 404, 0, 481 + 4 - 94), influenceRepeller);
//Attractors (propagator center is a local minimum)               
new Propagator(new Vector3D(530 - 493, 0, 481 + 4 - 374), influenceAttractor);
new Propagator(new Vector3D(530 - 488, 0, 481 + 4 - 369), influenceAttractor);
new Propagator(new Vector3D(530 - 483, 0, 481 + 4 - 364), influenceAttractor);
new Propagator(new Vector3D(530 - 479, 0, 481 + 4 - 359), influenceAttractor);
new Propagator(new Vector3D(530 - 483, 0, 481 + 4 - 364), influenceAttractor);
new Propagator(new Vector3D(530 - 468, 0, 481 + 4 - 146), influenceAttractor);
new Propagator(new Vector3D(530 - 463, 0, 481 + 4 - 144), influenceAttractor);
new Propagator(new Vector3D(530 - 458, 0, 481 + 4 - 142), influenceAttractor);
new Propagator(new Vector3D(530 - 453, 0, 481 + 4 - 140), influenceAttractor);
new Propagator(new Vector3D(530 - 448, 0, 481 + 4 - 139), influenceAttractor);
new Propagator(new Vector3D(530 - 443, 0, 481 + 4 - 138), influenceAttractor);
new Propagator(new Vector3D(530 - 438, 0, 481 + 4 - 137), influenceAttractor);
