function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(247 - 184, 0, 167 + 4 - 145), influenceRepeller);
new Propagator(new Vector3D(247 - 184, 0, 167 + 4 - 141), influenceRepeller);
new Propagator(new Vector3D(247 - 184, 0, 167 + 4 - 137), influenceRepeller);
new Propagator(new Vector3D(247 - 184, 0, 167 + 4 - 130), influenceRepeller);
new Propagator(new Vector3D(247 - 184, 0, 167 + 4 - 126), influenceRepeller);
new Propagator(new Vector3D(247 - 184, 0, 167 + 4 - 121), influenceRepeller);
new Propagator(new Vector3D(247 - 168, 0, 167 + 4 - 114), influenceRepeller);
new Propagator(new Vector3D(247 - 168, 0, 167 + 4 - 110), influenceRepeller);
new Propagator(new Vector3D(247 - 168, 0, 167 + 4 - 106), influenceRepeller);
new Propagator(new Vector3D(247 - 198, 0, 167 + 4 - 93), influenceRepeller);
new Propagator(new Vector3D(247 - 216, 0, 167 + 4 - 77), influenceRepeller);
new Propagator(new Vector3D(247 - 207, 0, 167 + 4 - 53), influenceRepeller);
new Propagator(new Vector3D(247 - 168, 0, 167 + 4 - 48), influenceRepeller);
new Propagator(new Vector3D(247 - 168, 0, 167 + 4 - 42), influenceRepeller);
//Attractors (propagator center is a local minimum)
new Propagator(new Vector3D(247 - 201, 0, 167 + 4 - 161), influenceAttractor);
new Propagator(new Vector3D(247 - 196, 0, 167 + 4 - 159), influenceAttractor);
new Propagator(new Vector3D(247 - 191, 0, 167 + 4 - 157), influenceAttractor);
new Propagator(new Vector3D(247 - 186, 0, 167 + 4 - 155), influenceAttractor);
new Propagator(new Vector3D(247 - 181, 0, 167 + 4 - 153), influenceAttractor);
new Propagator(new Vector3D(247 - 176, 0, 167 + 4 - 151), influenceAttractor);
new Propagator(new Vector3D(247 - 179, 0, 167 + 4 - 114), influenceAttractor);
new Propagator(new Vector3D(247 - 184, 0, 167 + 4 - 111), influenceAttractor);
new Propagator(new Vector3D(247 - 189, 0, 167 + 4 - 108), influenceAttractor);
new Propagator(new Vector3D(247 - 194, 0, 167 + 4 - 105), influenceAttractor);
new Propagator(new Vector3D(247 - 199, 0, 167 + 4 - 104), influenceAttractor);
new Propagator(new Vector3D(247 - 204, 0, 167 + 4 - 102), influenceAttractor);
