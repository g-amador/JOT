function Vector3D(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

function Propagator(position, influence) {
    print(position.x, position.y, position.z, influence);
}

//Repellers (propagator center is a local maximum)
new Propagator(new Vector3D(512 - 249, 0, 512 + 4 - 394), influenceRepeller);
new Propagator(new Vector3D(512 - 255, 0, 512 + 4 - 323), influenceRepeller);
new Propagator(new Vector3D(512 - 255, 0, 512 + 4 - 318), influenceRepeller);
new Propagator(new Vector3D(512 - 255, 0, 512 + 4 - 313), influenceRepeller);
new Propagator(new Vector3D(512 - 255, 0, 512 + 4 - 308), influenceRepeller);
new Propagator(new Vector3D(512 - 303, 0, 512 + 4 - 301), influenceRepeller);
new Propagator(new Vector3D(512 - 308, 0, 512 + 4 - 296), influenceRepeller);
new Propagator(new Vector3D(512 - 313, 0, 512 + 4 - 291), influenceRepeller);
new Propagator(new Vector3D(512 - 314, 0, 512 + 4 - 286), influenceRepeller);
new Propagator(new Vector3D(512 - 316, 0, 512 + 4 - 282), influenceRepeller);
new Propagator(new Vector3D(512 - 323, 0, 512 + 4 - 259), influenceRepeller);
new Propagator(new Vector3D(512 - 328, 0, 512 + 4 - 254), influenceRepeller);
new Propagator(new Vector3D(512 - 333, 0, 512 + 4 - 249), influenceRepeller);
new Propagator(new Vector3D(512 - 335, 0, 512 + 4 - 244), influenceRepeller);
new Propagator(new Vector3D(512 - 268, 0, 512 + 4 - 221), influenceRepeller);
new Propagator(new Vector3D(512 - 268, 0, 512 + 4 - 216), influenceRepeller);
new Propagator(new Vector3D(512 - 268, 0, 512 + 4 - 211), influenceRepeller);
new Propagator(new Vector3D(512 - 268, 0, 512 + 4 - 206), influenceRepeller);
new Propagator(new Vector3D(512 - 268, 0, 512 + 4 - 201), influenceRepeller);
new Propagator(new Vector3D(512 - 268, 0, 512 + 4 - 196), influenceRepeller);
new Propagator(new Vector3D(512 - 265, 0, 512 + 4 - 191), influenceRepeller);
new Propagator(new Vector3D(512 - 265, 0, 512 + 4 - 186), influenceRepeller);
//Attractors (propagator center is a local minimum)      
new Propagator(new Vector3D(512 - 307, 0, 512 + 4 - 467), influenceAttractor);
new Propagator(new Vector3D(512 - 305, 0, 512 + 4 - 462), influenceAttractor);
new Propagator(new Vector3D(512 - 303, 0, 512 + 4 - 457), influenceAttractor);
new Propagator(new Vector3D(512 - 301, 0, 512 + 4 - 452), influenceAttractor);
new Propagator(new Vector3D(512 - 299, 0, 512 + 4 - 447), influenceAttractor);
new Propagator(new Vector3D(512 - 297, 0, 512 + 4 - 442), influenceAttractor);
new Propagator(new Vector3D(512 - 295, 0, 512 + 4 - 437), influenceAttractor);
new Propagator(new Vector3D(512 - 293, 0, 512 + 4 - 432), influenceAttractor);
new Propagator(new Vector3D(512 - 291, 0, 512 + 4 - 427), influenceAttractor);
new Propagator(new Vector3D(512 - 289, 0, 512 + 4 - 422), influenceAttractor);
new Propagator(new Vector3D(512 - 287, 0, 512 + 4 - 417), influenceAttractor);
new Propagator(new Vector3D(512 - 285, 0, 512 + 4 - 412), influenceAttractor);
new Propagator(new Vector3D(512 - 283, 0, 512 + 4 - 407), influenceAttractor);
new Propagator(new Vector3D(512 - 281, 0, 512 + 4 - 402), influenceAttractor);
new Propagator(new Vector3D(512 - 279, 0, 512 + 4 - 397), influenceAttractor);
new Propagator(new Vector3D(512 - 276, 0, 512 + 4 - 392), influenceAttractor);
new Propagator(new Vector3D(512 - 278, 0, 512 + 4 - 320), influenceAttractor);
new Propagator(new Vector3D(512 - 279, 0, 512 + 4 - 315), influenceAttractor);
new Propagator(new Vector3D(512 - 280, 0, 512 + 4 - 310), influenceAttractor);
new Propagator(new Vector3D(512 - 281, 0, 512 + 4 - 305), influenceAttractor);
new Propagator(new Vector3D(512 - 282, 0, 512 + 4 - 300), influenceAttractor);
new Propagator(new Vector3D(512 - 283, 0, 512 + 4 - 295), influenceAttractor);
new Propagator(new Vector3D(512 - 284, 0, 512 + 4 - 290), influenceAttractor);
new Propagator(new Vector3D(512 - 285, 0, 512 + 4 - 285), influenceAttractor);
new Propagator(new Vector3D(512 - 286, 0, 512 + 4 - 280), influenceAttractor);
new Propagator(new Vector3D(512 - 287, 0, 512 + 4 - 275), influenceAttractor);
new Propagator(new Vector3D(512 - 288, 0, 512 + 4 - 270), influenceAttractor);
new Propagator(new Vector3D(512 - 290, 0, 512 + 4 - 265), influenceAttractor);
new Propagator(new Vector3D(512 - 292, 0, 512 + 4 - 260), influenceAttractor);
new Propagator(new Vector3D(512 - 294, 0, 512 + 4 - 255), influenceAttractor);
new Propagator(new Vector3D(512 - 296, 0, 512 + 4 - 250), influenceAttractor);
