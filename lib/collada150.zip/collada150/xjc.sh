#!/bin/sh

#30-37 set foreground color 45-47 set background color
#Black       30
#Red         31
#Green       32
#Brown       33
#Blue        34
#Purple      35
#Cyan        36
#Light Gray  37

#echo "\033[32mCompletely remove OpenJDK" 
#echo "\033[0m"
#sudo apt-get purge openjdk-\*
#echo "\033[32mDone! Press any key (not a actual key)." 
#echo "\033[0m"
#read var

xjc collada_schema_1_5.xsd -extension simpleMode.xsd
#java -Xmx1024m -jar jaxb-xjc.jar collada_schema_1_5.xsd -extension simpleMode.xsd
javac org/*/*/*/*/*
jar cvf collada150.jar org/*/*/*/*/*
rm -r org/
